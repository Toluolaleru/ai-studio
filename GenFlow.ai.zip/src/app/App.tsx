import { useState } from 'react';
import { AuthPage } from '@/app/components/auth-page';
import { Dashboard } from '@/app/components/dashboard';
import { Toaster } from 'sonner';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [userEmail, setUserEmail] = useState('');

  const handleLogin = (email: string) => {
    setUserEmail(email);
    setIsAuthenticated(true);
  };

  const handleLogout = () => {
    setIsAuthenticated(false);
    setUserEmail('');
  };

  if (isAuthenticated) {
    return (
      <>
        <Dashboard onLogout={handleLogout} userEmail={userEmail} />
        <Toaster position="top-right" richColors />
      </>
    );
  }

  return <AuthPage onLogin={handleLogin} />;
}
import { useState } from 'react';
import { Users, UserPlus, Crown, Shield, User, Eye, MoreVertical, Trash2, Mail, Check, Clock } from 'lucide-react';

interface TeamMember {
  id: string;
  email: string;
  name: string;
  role: 'owner' | 'admin' | 'member' | 'viewer';
  status: 'active' | 'pending';
  joinedAt: string;
  avatar?: string;
}

interface TeamMembersProps {
  teamName: string;
  teamId: string;
  currentUserEmail: string;
  members: TeamMember[];
  onInviteMember: () => void;
  onRemoveMember: (memberId: string) => void;
  onUpdateRole: (memberId: string, newRole: 'admin' | 'member' | 'viewer') => void;
}

export function TeamMembers({
  teamName,
  currentUserEmail,
  members,
  onInviteMember,
  onRemoveMember,
  onUpdateRole
}: TeamMembersProps) {
  const [openDropdown, setOpenDropdown] = useState<string | null>(null);

  const getRoleIcon = (role: string) => {
    switch (role) {
      case 'owner':
        return <Crown className="w-4 h-4 text-[#f59e0b]" />;
      case 'admin':
        return <Shield className="w-4 h-4 text-[#0000FF]" />;
      case 'member':
        return <User className="w-4 h-4 text-[#6b6b6b]" />;
      case 'viewer':
        return <Eye className="w-4 h-4 text-[#6b6b6b]" />;
      default:
        return null;
    }
  };

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'owner':
        return 'bg-[#fff4e8] text-[#f59e0b] border-[#f59e0b]/20';
      case 'admin':
        return 'bg-[#f0f7ff] text-[#0000FF] border-[#0000FF]/20';
      case 'member':
        return 'bg-[#f5f5f5] text-[#6b6b6b] border-[#e0e0e0]';
      case 'viewer':
        return 'bg-[#f5f5f5] text-[#6b6b6b] border-[#e0e0e0]';
      default:
        return 'bg-[#f5f5f5] text-[#6b6b6b] border-[#e0e0e0]';
    }
  };

  const currentUserMember = members.find(m => m.email === currentUserEmail);
  const isOwnerOrAdmin = currentUserMember && (currentUserMember.role === 'owner' || currentUserMember.role === 'admin');

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="border-b border-[#e0e0e0] px-8 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-[#0000FF]/10 rounded-xl flex items-center justify-center">
              <Users className="w-6 h-6 text-[#0000FF]" />
            </div>
            <div>
              <h2 className="text-[24px] font-bold text-[#1a1a1a]">Team Members</h2>
              <p className="text-[14px] text-[#6b6b6b]">{teamName} • {members.length} {members.length === 1 ? 'member' : 'members'}</p>
            </div>
          </div>
          {isOwnerOrAdmin && (
            <button
              onClick={onInviteMember}
              className="flex items-center gap-2 px-4 py-2.5 bg-[#0000FF] hover:bg-[#0000CC] text-white rounded-lg font-semibold text-[14px] transition-colors"
            >
              <UserPlus className="w-4 h-4" />
              Invite Member
            </button>
          )}
        </div>
      </div>

      {/* Members List */}
      <div className="flex-1 overflow-auto px-8 py-6">
        <div className="bg-white border border-[#e0e0e0] rounded-xl overflow-hidden">
          {/* Table Header */}
          <div className="bg-[#fafafa] border-b border-[#e0e0e0] px-6 py-3">
            <div className="grid grid-cols-12 gap-4 text-[12px] font-semibold text-[#6b6b6b] uppercase tracking-wider">
              <div className="col-span-5">Member</div>
              <div className="col-span-3">Role</div>
              <div className="col-span-3">Status</div>
              <div className="col-span-1"></div>
            </div>
          </div>

          {/* Members */}
          <div className="divide-y divide-[#e0e0e0]">
            {members.map((member) => (
              <div key={member.id} className="px-6 py-4 hover:bg-[#fafafa] transition-colors">
                <div className="grid grid-cols-12 gap-4 items-center">
                  {/* Member Info */}
                  <div className="col-span-5 flex items-center gap-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-[#0000FF] to-[#0000CC] rounded-full flex items-center justify-center text-white font-semibold text-[14px]">
                      {member.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <p className="text-[14px] font-semibold text-[#1a1a1a]">{member.name}</p>
                        {member.email === currentUserEmail && (
                          <span className="text-[11px] px-2 py-0.5 bg-[#f0f7ff] text-[#0000FF] rounded font-medium">
                            You
                          </span>
                        )}
                      </div>
                      <p className="text-[13px] text-[#6b6b6b]">{member.email}</p>
                    </div>
                  </div>

                  {/* Role */}
                  <div className="col-span-3">
                    <div className={`inline-flex items-center gap-2 px-3 py-1.5 rounded-lg border ${getRoleBadgeColor(member.role)}`}>
                      {getRoleIcon(member.role)}
                      <span className="text-[13px] font-semibold capitalize">{member.role}</span>
                    </div>
                  </div>

                  {/* Status */}
                  <div className="col-span-3">
                    {member.status === 'active' ? (
                      <div className="flex items-center gap-2">
                        <div className="w-2 h-2 bg-[#10b981] rounded-full"></div>
                        <span className="text-[13px] text-[#6b6b6b]">Active</span>
                      </div>
                    ) : (
                      <div className="flex items-center gap-2">
                        <Clock className="w-4 h-4 text-[#f59e0b]" />
                        <span className="text-[13px] text-[#f59e0b]">Pending</span>
                      </div>
                    )}
                  </div>

                  {/* Actions */}
                  <div className="col-span-1 flex justify-end">
                    {isOwnerOrAdmin && member.role !== 'owner' && member.email !== currentUserEmail && (
                      <div className="relative">
                        <button
                          onClick={() => setOpenDropdown(openDropdown === member.id ? null : member.id)}
                          className="p-2 hover:bg-[#e0e0e0] rounded-lg transition-colors"
                        >
                          <MoreVertical className="w-4 h-4 text-[#6b6b6b]" />
                        </button>

                        {/* Dropdown Menu */}
                        {openDropdown === member.id && (
                          <>
                            <div
                              className="fixed inset-0 z-40"
                              onClick={() => setOpenDropdown(null)}
                            />
                            <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-[#e0e0e0] rounded-lg shadow-lg overflow-hidden z-50">
                              {/* Change Role */}
                              <div className="border-b border-[#e0e0e0] p-2">
                                <p className="text-[11px] font-semibold text-[#6b6b6b] uppercase tracking-wider px-2 py-1">
                                  Change Role
                                </p>
                                {['admin', 'member', 'viewer'].map((roleOption) => (
                                  <button
                                    key={roleOption}
                                    onClick={() => {
                                      onUpdateRole(member.id, roleOption as 'admin' | 'member' | 'viewer');
                                      setOpenDropdown(null);
                                    }}
                                    className="w-full flex items-center justify-between px-3 py-2 hover:bg-[#f5f5f5] rounded-md transition-colors text-left"
                                  >
                                    <span className="text-[13px] text-[#1a1a1a] capitalize">{roleOption}</span>
                                    {member.role === roleOption && (
                                      <Check className="w-4 h-4 text-[#0000FF]" />
                                    )}
                                  </button>
                                ))}
                              </div>

                              {/* Remove Member */}
                              <button
                                onClick={() => {
                                  onRemoveMember(member.id);
                                  setOpenDropdown(null);
                                }}
                                className="w-full flex items-center gap-2 px-3 py-2 hover:bg-[#fef2f2] text-[#dc2626] transition-colors text-left"
                              >
                                <Trash2 className="w-4 h-4" />
                                <span className="text-[13px] font-medium">Remove Member</span>
                              </button>
                            </div>
                          </>
                        )}
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Empty State */}
        {members.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16">
            <div className="w-16 h-16 bg-[#f5f5f5] rounded-full flex items-center justify-center mb-4">
              <Users className="w-8 h-8 text-[#9b9b9b]" />
            </div>
            <h3 className="text-[18px] font-bold text-[#1a1a1a] mb-2">No members yet</h3>
            <p className="text-[14px] text-[#6b6b6b] mb-6 text-center max-w-sm">
              Invite team members to start collaborating on projects together.
            </p>
            {isOwnerOrAdmin && (
              <button
                onClick={onInviteMember}
                className="flex items-center gap-2 px-4 py-2.5 bg-[#0000FF] hover:bg-[#0000CC] text-white rounded-lg font-semibold text-[14px] transition-colors"
              >
                <UserPlus className="w-4 h-4" />
                Invite Member
              </button>
            )}
          </div>
        )}

        {/* Info Box */}
        {members.length > 0 && (
          <div className="mt-6 bg-[#f0f7ff] border border-[#0000FF]/20 rounded-lg p-4">
            <div className="flex gap-3">
              <Mail className="w-5 h-5 text-[#0000FF] flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-[13px] font-semibold text-[#1a1a1a] mb-1">
                  About Invitations
                </p>
                <p className="text-[13px] text-[#6b6b6b] leading-relaxed">
                  Members with "Pending" status have been invited but haven't joined yet. They'll receive an email invitation to join the team.
                </p>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

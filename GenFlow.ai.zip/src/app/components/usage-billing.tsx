import { useState } from 'react';
import { 
  TrendingUp, 
  DollarSign, 
  Calendar,
  Download,
  Image as ImageIcon,
  Video,
  Sparkles,
  AlertCircle
} from 'lucide-react';
import { 
  LineChart, 
  Line, 
  BarChart,
  Bar,
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  Legend,
  PieChart,
  Pie,
  Cell
} from 'recharts';

interface UsageData {
  date: string;
  imageGeneration: number;
  videoGeneration: number;
  imageEdit: number;
  total: number;
}

interface ModelUsage {
  model: string;
  requests: number;
  cost: number;
  percentage: number;
}

export function UsageBilling() {
  const [selectedPeriod, setSelectedPeriod] = useState<'7d' | '30d' | '90d'>('30d');

  // Mock data - In a real app, this would come from your backend
  const currentMonthSpend = 47.32;
  const lastMonthSpend = 52.18;
  const spendingLimit = 100.00;
  const totalRequests = 1247;
  const avgCostPerRequest = 0.038;

  // Daily usage data
  const usageData: UsageData[] = [
    { date: 'Jan 1', imageGeneration: 12.50, videoGeneration: 8.30, imageEdit: 3.20, total: 24.00 },
    { date: 'Jan 5', imageGeneration: 15.20, videoGeneration: 10.50, imageEdit: 4.10, total: 29.80 },
    { date: 'Jan 10', imageGeneration: 18.40, videoGeneration: 12.20, imageEdit: 5.30, total: 35.90 },
    { date: 'Jan 15', imageGeneration: 22.10, videoGeneration: 15.80, imageEdit: 6.50, total: 44.40 },
    { date: 'Jan 20', imageGeneration: 25.30, videoGeneration: 18.40, imageEdit: 7.20, total: 50.90 },
    { date: 'Jan 25', imageGeneration: 28.60, videoGeneration: 21.30, imageEdit: 8.10, total: 58.00 },
    { date: 'Jan 30', imageGeneration: 31.20, videoGeneration: 23.80, imageEdit: 9.40, total: 64.40 }
  ];

  // Model breakdown
  const modelUsage: ModelUsage[] = [
    { model: 'Image Generation', requests: 542, cost: 31.20, percentage: 66 },
    { model: 'Video Generation', requests: 423, cost: 23.80, percentage: 50 },
    { model: 'Image Editing', requests: 282, cost: 9.40, percentage: 20 }
  ];

  const pieData = modelUsage.map(item => ({
    name: item.model,
    value: item.cost
  }));

  const COLORS = ['#0000FF', '#5865f2', '#8B92FF'];

  const spendPercentage = (currentMonthSpend / spendingLimit) * 100;
  const isNearLimit = spendPercentage > 80;

  return (
    <div className="flex-1 overflow-y-auto bg-white">
      <div className="max-w-6xl mx-auto p-4 sm:p-6 md:p-8">
        {/* Header */}
        <div className="mb-6 md:mb-8">
          <h2 className="text-[20px] sm:text-[24px] font-bold text-[#1a1a1a] mb-2">Usage & Billing</h2>
          <p className="text-[13px] sm:text-[14px] text-[#6b6b6b]">Track your AI model usage and spending</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-4 mb-6 md:mb-8">
          {/* Current Month Spend */}
          <div className="bg-gradient-to-br from-[#0000FF] to-[#5865f2] rounded-xl p-6 text-white">
            <div className="flex items-center justify-between mb-4">
              <DollarSign className="w-8 h-8" />
              <span className="text-[12px] bg-white/20 px-2 py-1 rounded-full">This month</span>
            </div>
            <p className="text-[32px] font-bold mb-1">${currentMonthSpend.toFixed(2)}</p>
            <p className="text-[13px] opacity-90">Current spend</p>
            <div className="mt-4 flex items-center gap-2">
              <div className="flex-1 bg-white/20 rounded-full h-2">
                <div 
                  className="bg-white rounded-full h-2 transition-all duration-500"
                  style={{ width: `${Math.min(spendPercentage, 100)}%` }}
                />
              </div>
              <span className="text-[12px]">{spendPercentage.toFixed(0)}%</span>
            </div>
          </div>

          {/* Total Requests */}
          <div className="bg-white border border-[#e0e0e0] rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <Sparkles className="w-8 h-8 text-[#0000FF]" />
              <TrendingUp className="w-5 h-5 text-green-500" />
            </div>
            <p className="text-[32px] font-bold text-[#1a1a1a] mb-1">{totalRequests.toLocaleString()}</p>
            <p className="text-[13px] text-[#6b6b6b]">Total requests</p>
            <p className="text-[12px] text-green-500 mt-2">+12% from last month</p>
          </div>

          {/* Avg Cost per Request */}
          <div className="bg-white border border-[#e0e0e0] rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <Calendar className="w-8 h-8 text-[#0000FF]" />
            </div>
            <p className="text-[32px] font-bold text-[#1a1a1a] mb-1">${avgCostPerRequest.toFixed(3)}</p>
            <p className="text-[13px] text-[#6b6b6b]">Avg cost/request</p>
            <p className="text-[12px] text-[#6b6b6b] mt-2">Across all models</p>
          </div>

          {/* Spending Limit */}
          <div className="bg-white border border-[#e0e0e0] rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <AlertCircle className={`w-8 h-8 ${isNearLimit ? 'text-orange-500' : 'text-[#0000FF]'}`} />
              {isNearLimit && (
                <span className="text-[12px] bg-orange-100 text-orange-600 px-2 py-1 rounded-full font-medium">
                  Near limit
                </span>
              )}
            </div>
            <p className="text-[32px] font-bold text-[#1a1a1a] mb-1">${spendingLimit.toFixed(2)}</p>
            <p className="text-[13px] text-[#6b6b6b]">Monthly limit</p>
            <p className="text-[12px] text-[#6b6b6b] mt-2">${(spendingLimit - currentMonthSpend).toFixed(2)} remaining</p>
          </div>
        </div>

        {/* Chart Section */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 sm:gap-6 mb-6 md:mb-8">
          {/* Spend Over Time */}
          <div className="lg:col-span-2 bg-white border border-[#e0e0e0] rounded-xl p-4 sm:p-6">
            <div className="flex items-center justify-between mb-6">
              <div>
                <h3 className="text-[18px] font-bold text-[#1a1a1a] mb-1">Spending Trends</h3>
                <p className="text-[13px] text-[#6b6b6b]">Daily breakdown by model type</p>
              </div>
              <div className="flex gap-2">
                <button
                  onClick={() => setSelectedPeriod('7d')}
                  className={`px-3 py-1.5 rounded-lg text-[13px] font-medium transition-colors ${
                    selectedPeriod === '7d' 
                      ? 'bg-[#0000FF] text-white' 
                      : 'bg-[#f5f5f5] text-[#6b6b6b] hover:bg-[#e0e0e0]'
                  }`}
                >
                  7D
                </button>
                <button
                  onClick={() => setSelectedPeriod('30d')}
                  className={`px-3 py-1.5 rounded-lg text-[13px] font-medium transition-colors ${
                    selectedPeriod === '30d' 
                      ? 'bg-[#0000FF] text-white' 
                      : 'bg-[#f5f5f5] text-[#6b6b6b] hover:bg-[#e0e0e0]'
                  }`}
                >
                  30D
                </button>
                <button
                  onClick={() => setSelectedPeriod('90d')}
                  className={`px-3 py-1.5 rounded-lg text-[13px] font-medium transition-colors ${
                    selectedPeriod === '90d' 
                      ? 'bg-[#0000FF] text-white' 
                      : 'bg-[#f5f5f5] text-[#6b6b6b] hover:bg-[#e0e0e0]'
                  }`}
                >
                  90D
                </button>
              </div>
            </div>
            
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={usageData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#e0e0e0" />
                <XAxis 
                  dataKey="date" 
                  stroke="#6b6b6b" 
                  style={{ fontSize: '12px' }}
                />
                <YAxis 
                  stroke="#6b6b6b" 
                  style={{ fontSize: '12px' }}
                  tickFormatter={(value) => `$${value}`}
                />
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e0e0e0',
                    borderRadius: '8px',
                    fontSize: '13px'
                  }}
                  formatter={(value: number) => [`$${value.toFixed(2)}`, '']}
                />
                <Legend 
                  wrapperStyle={{ fontSize: '13px' }}
                  iconType="circle"
                />
                <Line 
                  type="monotone" 
                  dataKey="imageGeneration" 
                  stroke="#0000FF" 
                  strokeWidth={2}
                  name="Image Generation"
                  dot={{ fill: '#0000FF', r: 4 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="videoGeneration" 
                  stroke="#5865f2" 
                  strokeWidth={2}
                  name="Video Generation"
                  dot={{ fill: '#5865f2', r: 4 }}
                />
                <Line 
                  type="monotone" 
                  dataKey="imageEdit" 
                  stroke="#8B92FF" 
                  strokeWidth={2}
                  name="Image Editing"
                  dot={{ fill: '#8B92FF', r: 4 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          {/* Model Distribution */}
          <div className="bg-white border border-[#e0e0e0] rounded-xl p-6">
            <h3 className="text-[18px] font-bold text-[#1a1a1a] mb-1">Cost Distribution</h3>
            <p className="text-[13px] text-[#6b6b6b] mb-6">By model type</p>
            
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={pieData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {pieData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  contentStyle={{ 
                    backgroundColor: 'white', 
                    border: '1px solid #e0e0e0',
                    borderRadius: '8px',
                    fontSize: '13px'
                  }}
                  formatter={(value: number) => `$${value.toFixed(2)}`}
                />
              </PieChart>
            </ResponsiveContainer>

            <div className="mt-4 space-y-3">
              {modelUsage.map((item, index) => (
                <div key={item.model} className="flex items-center gap-3">
                  <div 
                    className="w-3 h-3 rounded-full"
                    style={{ backgroundColor: COLORS[index] }}
                  />
                  <div className="flex-1">
                    <p className="text-[13px] text-[#1a1a1a] font-medium">{item.model}</p>
                  </div>
                  <p className="text-[13px] font-bold text-[#1a1a1a]">${item.cost.toFixed(2)}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Model Usage Details */}
        <div className="bg-white border border-[#e0e0e0] rounded-xl p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-[18px] font-bold text-[#1a1a1a] mb-1">Model Usage Details</h3>
              <p className="text-[13px] text-[#6b6b6b]">Request volume and costs by model</p>
            </div>
            <button className="flex items-center gap-2 px-4 py-2 bg-[#f5f5f5] hover:bg-[#e0e0e0] text-[#1a1a1a] rounded-lg transition-colors text-[14px] font-medium">
              <Download className="w-4 h-4" />
              Export
            </button>
          </div>

          <div className="space-y-4">
            {modelUsage.map((item, index) => (
              <div key={item.model} className="border border-[#e0e0e0] rounded-lg p-4">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div 
                      className="w-10 h-10 rounded-lg flex items-center justify-center"
                      style={{ backgroundColor: COLORS[index] + '20' }}
                    >
                      {item.model.includes('Image') && <ImageIcon className="w-5 h-5" style={{ color: COLORS[index] }} />}
                      {item.model.includes('Video') && <Video className="w-5 h-5" style={{ color: COLORS[index] }} />}
                      {item.model.includes('Editing') && <Sparkles className="w-5 h-5" style={{ color: COLORS[index] }} />}
                    </div>
                    <div>
                      <h4 className="text-[15px] font-semibold text-[#1a1a1a]">{item.model}</h4>
                      <p className="text-[13px] text-[#6b6b6b]">{item.requests.toLocaleString()} requests</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-[18px] font-bold text-[#1a1a1a]">${item.cost.toFixed(2)}</p>
                    <p className="text-[13px] text-[#6b6b6b]">${(item.cost / item.requests).toFixed(4)}/req</p>
                  </div>
                </div>
                
                <div className="w-full bg-[#f5f5f5] rounded-full h-2">
                  <div 
                    className="rounded-full h-2 transition-all duration-500"
                    style={{ 
                      width: `${item.percentage}%`,
                      backgroundColor: COLORS[index]
                    }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Billing History */}
        <div className="bg-white border border-[#e0e0e0] rounded-xl p-6">
          <h3 className="text-[18px] font-bold text-[#1a1a1a] mb-4">Billing History</h3>
          
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-[#e0e0e0]">
                  <th className="text-left py-3 px-4 text-[13px] font-semibold text-[#6b6b6b] uppercase tracking-wider">Period</th>
                  <th className="text-left py-3 px-4 text-[13px] font-semibold text-[#6b6b6b] uppercase tracking-wider">Requests</th>
                  <th className="text-left py-3 px-4 text-[13px] font-semibold text-[#6b6b6b] uppercase tracking-wider">Amount</th>
                  <th className="text-left py-3 px-4 text-[13px] font-semibold text-[#6b6b6b] uppercase tracking-wider">Status</th>
                  <th className="text-right py-3 px-4 text-[13px] font-semibold text-[#6b6b6b] uppercase tracking-wider">Invoice</th>
                </tr>
              </thead>
              <tbody>
                <tr className="border-b border-[#e0e0e0] hover:bg-[#fafafa] transition-colors">
                  <td className="py-4 px-4 text-[14px] text-[#1a1a1a] font-medium">January 2026</td>
                  <td className="py-4 px-4 text-[14px] text-[#6b6b6b]">1,247</td>
                  <td className="py-4 px-4 text-[14px] font-semibold text-[#1a1a1a]">${currentMonthSpend.toFixed(2)}</td>
                  <td className="py-4 px-4">
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-blue-100 text-[#0000FF] rounded-full text-[12px] font-medium">
                      Current
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <button className="text-[#0000FF] hover:underline text-[14px] font-medium">
                      View
                    </button>
                  </td>
                </tr>
                <tr className="border-b border-[#e0e0e0] hover:bg-[#fafafa] transition-colors">
                  <td className="py-4 px-4 text-[14px] text-[#1a1a1a] font-medium">December 2025</td>
                  <td className="py-4 px-4 text-[14px] text-[#6b6b6b]">1,108</td>
                  <td className="py-4 px-4 text-[14px] font-semibold text-[#1a1a1a]">${lastMonthSpend.toFixed(2)}</td>
                  <td className="py-4 px-4">
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-green-100 text-green-600 rounded-full text-[12px] font-medium">
                      Paid
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <button className="text-[#0000FF] hover:underline text-[14px] font-medium">
                      Download
                    </button>
                  </td>
                </tr>
                <tr className="border-b border-[#e0e0e0] hover:bg-[#fafafa] transition-colors">
                  <td className="py-4 px-4 text-[14px] text-[#1a1a1a] font-medium">November 2025</td>
                  <td className="py-4 px-4 text-[14px] text-[#6b6b6b]">892</td>
                  <td className="py-4 px-4 text-[14px] font-semibold text-[#1a1a1a]">$38.54</td>
                  <td className="py-4 px-4">
                    <span className="inline-flex items-center gap-1 px-2 py-1 bg-green-100 text-green-600 rounded-full text-[12px] font-medium">
                      Paid
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <button className="text-[#0000FF] hover:underline text-[14px] font-medium">
                      Download
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}

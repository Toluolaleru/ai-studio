import { useState } from 'react';
import { X, Users } from 'lucide-react';

interface CreateTeamModalProps {
  onClose: () => void;
  onCreateTeam: (teamName: string, teamDescription: string) => void;
}

export function CreateTeamModal({ onClose, onCreateTeam }: CreateTeamModalProps) {
  const [teamName, setTeamName] = useState('');
  const [teamDescription, setTeamDescription] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (teamName.trim()) {
      onCreateTeam(teamName.trim(), teamDescription.trim());
      onClose();
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[#e0e0e0]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#0000FF]/10 rounded-lg flex items-center justify-center">
              <Users className="w-5 h-5 text-[#0000FF]" />
            </div>
            <h2 className="text-[20px] font-bold text-[#1a1a1a]">Create New Team</h2>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-[#f5f5f5] rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-[#6b6b6b]" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Team Name */}
          <div>
            <label className="block text-[13px] font-semibold text-[#1a1a1a] mb-2">
              Team Name <span className="text-[#dc2626]">*</span>
            </label>
            <input
              type="text"
              value={teamName}
              onChange={(e) => setTeamName(e.target.value)}
              placeholder="e.g., Marketing Team, Design Squad"
              className="w-full px-4 py-3 bg-[#fafafa] border border-[#e0e0e0] rounded-lg text-[14px] text-[#1a1a1a] placeholder:text-[#9b9b9b] focus:outline-none focus:ring-2 focus:ring-[#0000FF] focus:border-transparent transition-all"
              required
            />
          </div>

          {/* Team Description */}
          <div>
            <label className="block text-[13px] font-semibold text-[#1a1a1a] mb-2">
              Description (Optional)
            </label>
            <textarea
              value={teamDescription}
              onChange={(e) => setTeamDescription(e.target.value)}
              placeholder="What's this team for?"
              rows={3}
              className="w-full px-4 py-3 bg-[#fafafa] border border-[#e0e0e0] rounded-lg text-[14px] text-[#1a1a1a] placeholder:text-[#9b9b9b] focus:outline-none focus:ring-2 focus:ring-[#0000FF] focus:border-transparent transition-all resize-none"
            />
          </div>

          {/* Info Box */}
          <div className="bg-[#f0f7ff] border border-[#0000FF]/20 rounded-lg p-4">
            <p className="text-[13px] text-[#1a1a1a] leading-relaxed">
              You'll be able to invite team members after creating your team.
            </p>
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 bg-white border border-[#e0e0e0] hover:bg-[#f5f5f5] text-[#1a1a1a] rounded-lg font-semibold text-[14px] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!teamName.trim()}
              className="flex-1 px-4 py-3 bg-[#0000FF] hover:bg-[#0000CC] text-white rounded-lg font-semibold text-[14px] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Create Team
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

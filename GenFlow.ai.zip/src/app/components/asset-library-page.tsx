import React, { useState } from 'react';
import { FolderOpen, Upload, ImageIcon, Video, FileText, Search } from 'lucide-react';
import { GenerationCard, Generation } from './generation-card';

interface AssetLibraryPageProps {
  onOpenImagePlayground?: () => void;
}

// Mock generations data
const mockGenerations: Generation[] = [
  {
    id: '1',
    type: 'image',
    prompt: 'i want to create an image collage as seen in the reference 1. but with my face as uploaded',
    images: [
      'https://images.unsplash.com/photo-1689279699483-91fc40564c5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHNtaWxpbmclMjB5ZWxsb3clMjBkcmVzcyUyMGZsb3dlcnN8ZW58MXx8fHwxNzcwMDA4NDk4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1760406852142-3316e140db3b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsaWZlc3R5bGUlMjBwcm9kdWN0JTIwc2NlbmV8ZW58MXx8fHwxNzcwMDA4NDk4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1567003762442-2078a0da1cee?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGNvbG9yZnVsJTIwYXJ0JTIwY3JlYXRpdmV8ZW58MXx8fHwxNzcwMDA4NDk4fDA&ixlib=rb-4.1.0&q=80&w=1080',
      'https://images.unsplash.com/photo-1689279699483-91fc40564c5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHNtaWxpbmclMjB5ZWxsb3clMjBkcmVzcyUyMGZsb3dlcnN8ZW58MXx8fHwxNzcwMDA4NDk4fDA&ixlib=rb-4.1.0&q=80&w=1080',
    ],
    model: 'Nano Banana',
    dimensions: '21:9',
    resolution: '2K',
    timestamp: new Date('2026-02-07'),
    referenceImages: [
      {
        id: 'ref1',
        url: 'https://images.unsplash.com/photo-1689279699483-91fc40564c5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHNtaWxpbmclMjB5ZWxsb3clMjBkcmVzcyUyMGZsb3dlcnN8ZW58MXx8fHwxNzcwMDA4NDk4fDA&ixlib=rb-4.1.0&q=80&w=200',
        name: 'reference-1.jpg'
      },
      {
        id: 'ref2',
        url: 'https://images.unsplash.com/photo-1567003762442-2078a0da1cee?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGNvbG9yZnVsJTIwYXJ0JTIwY3JlYXRpdmV8ZW58MXx8fHwxNzcwMDA4NDk4fDA&ixlib=rb-4.1.0&q=80&w=200',
        name: 'uploaded-face.jpg'
      }
    ]
  }
];

export function AssetLibraryPage({ onOpenImagePlayground }: AssetLibraryPageProps) {
  const [activeTab, setActiveTab] = useState<'uploads' | 'generations' | 'brand'>('uploads');
  const [searchQuery, setSearchQuery] = useState('');
  const [generationsFilter, setGenerationsFilter] = useState<'all' | 'images' | 'videos'>('all');

  const tabs = [
    { id: 'uploads' as const, label: 'My uploads' },
    { id: 'generations' as const, label: 'Generations' },
    { id: 'brand' as const, label: 'Brand Assets' },
  ];

  return (
    <div className="flex-1 flex flex-col bg-white">
      {/* Tabs */}
      <div className="border-b border-[#e0e0e0] px-4 md:px-8 bg-white">
        <div className="flex items-center gap-0 overflow-x-auto scrollbar-hide">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-4 md:px-6 py-4 text-[13px] md:text-[14px] font-medium whitespace-nowrap transition-colors relative ${
                activeTab === tab.id
                  ? 'text-[#0000FF]'
                  : 'text-[#6b6b6b] hover:text-[#1a1a1a]'
              }`}
            >
              {tab.label}
              {activeTab === tab.id && (
                <div className="absolute bottom-0 left-0 right-0 h-[2px] bg-[#0000FF]" />
              )}
            </button>
          ))}
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 overflow-auto p-4 md:p-8">
        {activeTab === 'uploads' && (
          <div className="flex flex-col items-center justify-center h-full pt-32">
            <h3 className="text-[18px] font-semibold text-[#1a1a1a] mb-2">
              No uploads yet
            </h3>
            <p className="text-[14px] text-[#6b6b6b] mb-6 text-center max-w-md">
              Upload images, videos, or files to get started
            </p>
            <button className="px-6 py-3 bg-[#0000FF] text-white rounded-lg text-[14px] font-medium hover:bg-[#0000CC] transition-colors">
              Upload Files
            </button>
          </div>
        )}

        {activeTab === 'generations' && (
          <>
            {/* Search and Filter Bar */}
            <div className="mb-6 flex flex-col md:flex-row gap-4">
              {/* Search Bar */}
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-[#6b6b6b]" />
                <input
                  type="text"
                  placeholder="Search generations..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 border border-[#e0e0e0] rounded-lg text-[14px] text-[#1a1a1a] placeholder:text-[#6b6b6b] focus:outline-none focus:ring-2 focus:ring-[#0000FF] focus:border-transparent"
                />
              </div>

              {/* Filter Buttons */}
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setGenerationsFilter('all')}
                  className={`px-4 py-2.5 rounded-lg text-[14px] font-medium transition-colors ${
                    generationsFilter === 'all'
                      ? 'bg-[#0000FF] text-white'
                      : 'bg-[#f5f5f5] text-[#6b6b6b] hover:bg-[#e0e0e0]'
                  }`}
                >
                  All
                </button>
                <button
                  onClick={() => setGenerationsFilter('images')}
                  className={`px-4 py-2.5 rounded-lg text-[14px] font-medium transition-colors flex items-center gap-2 ${
                    generationsFilter === 'images'
                      ? 'bg-[#0000FF] text-white'
                      : 'bg-[#f5f5f5] text-[#6b6b6b] hover:bg-[#e0e0e0]'
                  }`}
                >
                  <ImageIcon className="w-4 h-4" />
                  Images
                </button>
                <button
                  onClick={() => setGenerationsFilter('videos')}
                  className={`px-4 py-2.5 rounded-lg text-[14px] font-medium transition-colors flex items-center gap-2 ${
                    generationsFilter === 'videos'
                      ? 'bg-[#0000FF] text-white'
                      : 'bg-[#f5f5f5] text-[#6b6b6b] hover:bg-[#e0e0e0]'
                  }`}
                >
                  <Video className="w-4 h-4" />
                  Videos
                </button>
              </div>
            </div>

            {/* Generations List */}
            <div className="space-y-6">
              {/* Date Header */}
              <h2 className="text-[14px] font-semibold text-[#6b6b6b]">Feb 7</h2>
              
              {/* Generations */}
              {mockGenerations
                .filter((generation) =>
                  generation.prompt.toLowerCase().includes(searchQuery.toLowerCase())
                )
                .filter((generation) => {
                  if (generationsFilter === 'all') return true;
                  if (generationsFilter === 'images' && generation.type === 'image') return true;
                  if (generationsFilter === 'videos' && generation.type === 'video') return true;
                  return false;
                })
                .map((generation) => (
                  <GenerationCard key={generation.id} generation={generation} />
                ))}
            </div>
          </>
        )}

        {activeTab === 'brand' && (
          <div className="flex flex-col items-center justify-center h-full pt-32">
            <h3 className="text-[18px] font-semibold text-[#1a1a1a] mb-2">
              No brand assets yet
            </h3>
            <p className="text-[14px] text-[#6b6b6b] mb-6 text-center max-w-md">
              Upload your brand logos, colors, and guidelines to maintain brand consistency
            </p>
            <button className="px-6 py-3 bg-[#0000FF] text-white rounded-lg text-[14px] font-medium hover:bg-[#0000CC] transition-colors">
              Add Brand Assets
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
import { useState } from 'react';
import { X, Mail, UserPlus } from 'lucide-react';

interface InviteMemberModalProps {
  onClose: () => void;
  onInviteMember: (email: string, role: 'admin' | 'member' | 'viewer') => void;
  teamName: string;
}

export function InviteMemberModal({ onClose, onInviteMember, teamName }: InviteMemberModalProps) {
  const [email, setEmail] = useState('');
  const [role, setRole] = useState<'admin' | 'member' | 'viewer'>('member');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (email.trim() && email.includes('@')) {
      onInviteMember(email.trim(), role);
      setEmail('');
    }
  };

  const roles = [
    {
      value: 'admin' as const,
      label: 'Admin',
      description: 'Can manage team settings and members'
    },
    {
      value: 'member' as const,
      label: 'Member',
      description: 'Can create and edit content'
    },
    {
      value: 'viewer' as const,
      label: 'Viewer',
      description: 'Can only view content'
    }
  ];

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-[#e0e0e0]">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-[#0000FF]/10 rounded-lg flex items-center justify-center">
              <UserPlus className="w-5 h-5 text-[#0000FF]" />
            </div>
            <div>
              <h2 className="text-[20px] font-bold text-[#1a1a1a]">Invite Member</h2>
              <p className="text-[13px] text-[#6b6b6b]">{teamName}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 hover:bg-[#f5f5f5] rounded-lg transition-colors"
          >
            <X className="w-5 h-5 text-[#6b6b6b]" />
          </button>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-6 space-y-5">
          {/* Email Input */}
          <div>
            <label className="block text-[13px] font-semibold text-[#1a1a1a] mb-2">
              Email Address <span className="text-[#dc2626]">*</span>
            </label>
            <div className="relative">
              <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6b6b6b]" />
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="colleague@example.com"
                className="w-full pl-10 pr-4 py-3 bg-[#fafafa] border border-[#e0e0e0] rounded-lg text-[14px] text-[#1a1a1a] placeholder:text-[#9b9b9b] focus:outline-none focus:ring-2 focus:ring-[#0000FF] focus:border-transparent transition-all"
                required
              />
            </div>
          </div>

          {/* Role Selection */}
          <div>
            <label className="block text-[13px] font-semibold text-[#1a1a1a] mb-3">
              Role
            </label>
            <div className="space-y-2">
              {roles.map((roleOption) => (
                <label
                  key={roleOption.value}
                  className={`flex items-start gap-3 p-4 border-2 rounded-lg cursor-pointer transition-all ${
                    role === roleOption.value
                      ? 'border-[#0000FF] bg-[#f0f7ff]'
                      : 'border-[#e0e0e0] hover:border-[#0000FF]/30 bg-white'
                  }`}
                >
                  <input
                    type="radio"
                    name="role"
                    value={roleOption.value}
                    checked={role === roleOption.value}
                    onChange={(e) => setRole(e.target.value as 'admin' | 'member' | 'viewer')}
                    className="mt-0.5 w-4 h-4 text-[#0000FF] border-[#e0e0e0] focus:ring-[#0000FF]"
                  />
                  <div className="flex-1">
                    <div className="text-[14px] font-semibold text-[#1a1a1a]">
                      {roleOption.label}
                    </div>
                    <div className="text-[13px] text-[#6b6b6b] mt-0.5">
                      {roleOption.description}
                    </div>
                  </div>
                </label>
              ))}
            </div>
          </div>

          {/* Buttons */}
          <div className="flex gap-3 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-3 bg-white border border-[#e0e0e0] hover:bg-[#f5f5f5] text-[#1a1a1a] rounded-lg font-semibold text-[14px] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={!email.trim() || !email.includes('@')}
              className="flex-1 px-4 py-3 bg-[#0000FF] hover:bg-[#0000CC] text-white rounded-lg font-semibold text-[14px] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
            >
              Send Invite
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

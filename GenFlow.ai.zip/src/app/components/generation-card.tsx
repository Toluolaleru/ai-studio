import { useState } from 'react';
import {
  MoreVertical,
  Download,
  Trash2,
  Copy,
  RotateCcw,
  Crop,
  Maximize2,
  Eye,
} from 'lucide-react';

export interface Generation {
  id: string;
  type: 'image' | 'video';
  prompt: string;
  images: string[];
  model: string;
  dimensions: string;
  resolution: string;
  timestamp: Date;
  referenceImages?: Array<{ id: string; url: string; name: string }>;
}

interface GenerationCardProps {
  generation: Generation;
  onIterate?: (generationId: string) => void;
}

export function GenerationCard({ generation, onIterate }: GenerationCardProps) {
  const [selectedGenerationMenu, setSelectedGenerationMenu] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (text: string) => {
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      document.execCommand('copy');
      textArea.remove();
    } catch (err) {
      console.error('Failed to copy text: ', err);
      textArea.remove();
    }
  };

  return (
    <div className="bg-white rounded-xl hover:shadow-lg transition-shadow">
      <div className="flex flex-col lg:flex-row gap-4">
        {/* Images Grid - Left Side (takes up more space) */}
        <div className="w-full lg:w-[70%] flex-shrink-0">
          {generation.images.length === 1 ? (
            // Single Image
            <div className="relative bg-[#f5f5f5] rounded-lg overflow-hidden h-[250px] group">
              <img
                src={generation.images[0]}
                alt={generation.prompt}
                className="w-full h-full object-cover cursor-pointer hover:opacity-90 transition-opacity"
              />
              {/* Action buttons - Show only on hover */}
              <div className="absolute top-3 left-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                <button className="p-2.5 bg-white hover:bg-[#f5f5f5] rounded-xl transition-colors shadow-md">
                  <Download className="w-4 h-4 text-[#1a1a1a]" />
                </button>
                <button className="p-2.5 bg-white hover:bg-[#f5f5f5] rounded-xl transition-colors shadow-md">
                  <Eye className="w-4 h-4 text-[#1a1a1a]" />
                </button>
                <button className="p-2.5 bg-white hover:bg-[#f5f5f5] rounded-xl transition-colors shadow-md">
                  <Trash2 className="w-4 h-4 text-[#1a1a1a]" />
                </button>
              </div>
            </div>
          ) : (
            // Grid of Multiple Images (2x2 for 4 images)
            <div className="grid grid-cols-2 gap-3">
              {generation.images.map((image, index) => (
                <div
                  key={index}
                  className="relative bg-[#f5f5f5] rounded-lg overflow-hidden aspect-[4/3] group"
                >
                  <img
                    src={image}
                    alt={`${generation.prompt} - ${index + 1}`}
                    className="w-full h-full object-cover cursor-pointer hover:opacity-90 transition-opacity"
                  />
                  {/* Action buttons - Show only on hover in top-left corner */}
                  <div className="absolute top-3 left-3 flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button className="p-2.5 bg-white hover:bg-[#f5f5f5] rounded-xl transition-colors shadow-md">
                      <Download className="w-4 h-4 text-[#1a1a1a]" />
                    </button>
                    <button className="p-2.5 bg-white hover:bg-[#f5f5f5] rounded-xl transition-colors shadow-md">
                      <Eye className="w-4 h-4 text-[#1a1a1a]" />
                    </button>
                    <button className="p-2.5 bg-white hover:bg-[#f5f5f5] rounded-xl transition-colors shadow-md">
                      <Trash2 className="w-4 h-4 text-[#1a1a1a]" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Prompt Card - Right Side */}
        <div className="flex-1 flex flex-col justify-between bg-[#fafafa] rounded-lg p-4 border border-[#e0e0e0]">
          {/* Top Section */}
          <div className="space-y-4">
            {/* Prompt with Copy Icon */}
            <div className="flex items-start gap-2 group">
              <p className="text-[14px] text-[#1a1a1a] leading-relaxed flex-1">
                {generation.prompt}
              </p>
              <div className="relative">
                <button
                  onClick={() => {
                    copyToClipboard(generation.prompt);
                    setCopiedId(generation.id);
                    setTimeout(() => setCopiedId(null), 2000);
                  }}
                  className="p-1.5 hover:bg-[#f5f5f5] rounded transition-colors opacity-0 group-hover:opacity-100"
                  title="Copy prompt"
                >
                  <Copy className="w-4 h-4 text-[#6b6b6b]" />
                </button>
                {copiedId === generation.id && (
                  <div className="absolute right-0 top-full mt-1 px-2 py-1 bg-[#1a1a1a] text-white text-[11px] rounded whitespace-nowrap">
                    Copied!
                  </div>
                )}
              </div>
            </div>

            {/* Reference Images Display */}
            {generation.referenceImages && generation.referenceImages.length > 0 && (
              <div className="flex items-center gap-2 flex-wrap">
                {generation.referenceImages.map((refImage, index) => (
                  <div
                    key={refImage.id}
                    className="relative w-16 h-16 rounded-lg overflow-visible bg-[#f5f5f5] cursor-pointer border border-[#e0e0e0] group"
                  >
                    <img
                      src={refImage.url}
                      alt={refImage.name}
                      className="w-full h-full object-cover rounded-lg"
                    />
                    {/* Custom Tooltip */}
                    <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 bg-[#1a1a1a] text-white text-[12px] font-medium rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-50 shadow-lg">
                      Reference image {index + 1}
                      {/* Arrow pointing down */}
                      <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-[1px] border-4 border-transparent border-t-[#1a1a1a]"></div>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Metadata - Grey Card Badges */}
            <div className="flex items-center gap-2 text-[12px]">
              {/* Model Badge */}
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#f5f5f5] rounded-lg border border-[#e0e0e0]">
                <div className="w-1.5 h-1.5 bg-[#0000FF] rounded-full"></div>
                <span className="font-medium text-[#1a1a1a]">{generation.model}</span>
              </div>
              {/* Dimensions Badge (Aspect Ratio) */}
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#f5f5f5] rounded-lg border border-[#e0e0e0]">
                <Crop className="w-3.5 h-3.5 text-[#6b6b6b]" />
                <span className="font-medium text-[#1a1a1a]">{generation.dimensions}</span>
              </div>
              {/* Resolution Badge */}
              <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#f5f5f5] rounded-lg border border-[#e0e0e0]">
                <Maximize2 className="w-3.5 h-3.5 text-[#6b6b6b]" />
                <span className="font-medium text-[#1a1a1a]">{generation.resolution}</span>
              </div>
            </div>

            {/* Action Buttons */}
            <div className="flex items-center gap-2 pt-2">
              <button
                className="flex items-center gap-2 px-4 py-2 bg-white border border-[#e0e0e0] hover:bg-[#f5f5f5] text-[#1a1a1a] rounded-lg text-[13px] font-semibold transition-colors"
                onClick={() => onIterate?.(generation.id)}
              >
                <RotateCcw className="w-4 h-4" />
                Iterate
              </button>
              <div className="relative group">
                <button className="p-2 bg-[#f5f5f5] hover:bg-[#e0e0e0] rounded-lg transition-colors shadow-sm">
                  <Download className="w-4 h-4 text-[#1a1a1a]" />
                </button>
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-[#1a1a1a] text-white text-[11px] rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                  Download all
                </div>
              </div>
              <div className="relative group">
                <button className="p-2 bg-[#f5f5f5] hover:bg-[#e0e0e0] rounded-lg transition-colors shadow-sm">
                  <Trash2 className="w-4 h-4 text-[#1a1a1a]" />
                </button>
                <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-[#1a1a1a] text-white text-[11px] rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                  Delete all
                </div>
              </div>
              <div className="relative">
                <button
                  onClick={() =>
                    setSelectedGenerationMenu(
                      selectedGenerationMenu === generation.id ? null : generation.id
                    )
                  }
                  className="p-2 bg-[#f5f5f5] hover:bg-[#e0e0e0] rounded-lg transition-colors shadow-sm"
                >
                  <MoreVertical className="w-4 h-4 text-[#1a1a1a]" />
                </button>

                {/* Dropdown Menu */}
                {selectedGenerationMenu === generation.id && (
                  <div className="absolute right-0 top-full mt-1 w-56 bg-white border border-[#e0e0e0] rounded-xl shadow-xl z-50 overflow-hidden py-1">
                    <button className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#f5f5f5] transition-colors text-left">
                      <RotateCcw className="w-4 h-4 text-[#1a1a1a]" />
                      <span className="text-[12px] text-[#1a1a1a]">Generate Again</span>
                    </button>
                    <button className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#f5f5f5] transition-colors text-left">
                      <Download className="w-4 h-4 text-[#1a1a1a]" />
                      <span className="text-[12px] text-[#1a1a1a]">Download All</span>
                    </button>
                    <button className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#f5f5f5] transition-colors text-left">
                      <Trash2 className="w-4 h-4 text-[#1a1a1a]" />
                      <span className="text-[12px] text-[#1a1a1a]">Delete All</span>
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Bottom Section - Feedback */}
          <div className="pt-4 border-t border-[#e0e0e0] mt-4">
            <div className="flex items-center justify-between">
              <span className="text-[13px] text-[#6b6b6b]">How was this output?</span>
              <div className="flex items-center gap-2">
                <button className="p-1.5 hover:bg-[#f5f5f5] rounded transition-colors">
                  <svg
                    className="w-4 h-4 text-[#6b6b6b]"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3"
                    />
                  </svg>
                </button>
                <button className="p-1.5 hover:bg-[#f5f5f5] rounded transition-colors">
                  <svg
                    className="w-4 h-4 text-[#6b6b6b]"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    viewBox="0 0 24 24"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17"
                    />
                  </svg>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
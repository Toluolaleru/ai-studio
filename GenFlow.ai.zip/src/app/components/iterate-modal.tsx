import { X, Sparkles, Image } from 'lucide-react';
import { useState, useEffect } from 'react';

interface IterateModalProps {
  generationId: string;
  onClose: () => void;
  onGenerate?: (prompt: string, imageCount: number) => void;
  buttonRef?: React.RefObject<HTMLButtonElement>;
}

export function IterateModal({ generationId, onClose, onGenerate, buttonRef }: IterateModalProps) {
  const [prompt, setPrompt] = useState('');
  const [imageCount, setImageCount] = useState(1);
  const [position, setPosition] = useState({ top: 0, left: 0 });

  useEffect(() => {
    if (buttonRef?.current) {
      const rect = buttonRef.current.getBoundingClientRect();
      setPosition({
        top: rect.bottom + window.scrollY + 8, // 8px gap below button
        left: rect.left + window.scrollX,
      });
    }
  }, [buttonRef]);

  const handleGenerate = () => {
    if (onGenerate) {
      onGenerate(prompt, imageCount);
    }
    setPrompt('');
    onClose();
  };

  return (
    <>
      {/* Subtle backdrop */}
      <div className="fixed inset-0 bg-black/20 z-50" onClick={onClose}></div>
      
      {/* Compact dropdown panel */}
      <div 
        className="fixed bg-white rounded-xl w-[calc(100vw-2rem)] max-w-[600px] shadow-2xl border border-[#e0e0e0] z-50 mx-4"
        style={{
          top: position.top ? `${position.top}px` : '50%',
          left: position.left ? `${position.left}px` : '50%',
          transform: position.top ? 'none' : 'translate(-50%, -50%)',
        }}
      >
        {/* Header */}
        <div className="flex items-center justify-between px-4 sm:px-5 py-3 border-b border-[#e0e0e0]">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-[#0000FF]" />
            <h2 className="text-[14px] sm:text-[15px] font-semibold text-[#1a1a1a]">
              Edit prompt with <span className="text-[#0000FF]">AI</span>
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1 hover:bg-[#f5f5f5] rounded-lg transition-colors"
          >
            <X className="w-4 h-4 text-[#666]" />
          </button>
        </div>

        {/* Content */}
        <div className="p-4 sm:p-5 space-y-3">
          {/* Examples */}
          <p className="text-[12px] text-[#666]">
            Examples: "change the coat to red" or "add a blue hat" or "make it vintage"
          </p>

          {/* Textarea */}
          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Type what you would like to change..."
            className="w-full h-24 px-4 py-3 bg-white border-2 border-[#0000FF] rounded-xl text-[14px] text-[#1a1a1a] placeholder:text-[#999] focus:outline-none focus:border-[#0000FF] resize-none"
          />

          {/* Controls */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-end gap-3">
            {/* Image Count Selector */}
            <div className="flex items-center gap-2 px-3 py-2 bg-[#f5f5f5] rounded-lg">
              <Image className="w-4 h-4 text-[#666]" />
              <select
                value={imageCount}
                onChange={(e) => setImageCount(Number(e.target.value))}
                className="bg-transparent text-[13px] font-medium text-[#1a1a1a] outline-none cursor-pointer"
              >
                {[1, 2, 3, 4, 5, 6, 7, 8].map((num) => (
                  <option key={num} value={num}>
                    {num}
                  </option>
                ))}
              </select>
            </div>

            {/* Generate Button */}
            <button
              onClick={handleGenerate}
              disabled={!prompt.trim()}
              className="flex items-center gap-2 px-6 py-2 bg-[#0000FF] hover:bg-[#0000CC] disabled:bg-[#e0e0e0] disabled:text-[#999] text-white rounded-lg text-[13px] font-semibold transition-colors"
            >
              Generate
            </button>
          </div>
        </div>
      </div>
    </>
  );
}
import { useState } from 'react';
import { ArrowLeft, Eye, EyeOff } from 'lucide-react';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';

interface ForgotPasswordProps {
  onBack: () => void;
}

export function ForgotPassword({ onBack }: ForgotPasswordProps) {
  const [email, setEmail] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [showResetForm, setShowResetForm] = useState(false);
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    console.log('Password reset requested for:', email);
    setIsSubmitted(true);
  };

  const handlePasswordReset = (e: React.FormEvent) => {
    e.preventDefault();
    if (newPassword !== confirmPassword) {
      alert('Passwords do not match');
      return;
    }
    console.log('Password reset successfully');
    // Redirect to login
    onBack();
  };

  // Reset password form (accessed via email link)
  if (showResetForm) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#fafafa] p-4 relative">
        {/* Back Button - Top Left */}
        <button
          onClick={onBack}
          className="absolute top-8 left-8 flex items-center gap-2 text-[#6b6b6b] hover:text-[#1a1a1a] transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="text-[14px]">Back to login</span>
        </button>

        <div className="w-full max-w-[400px]">
          {/* Logo */}
          <div className="flex justify-center mb-4">
            <div className="w-14 h-14 bg-[#1a1a1a] rounded-full flex items-center justify-center">
              <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
            </div>
          </div>

          {/* Platform Name */}
          <div className="text-center mb-8">
            <h2 className="text-[18px] font-medium text-[#1a1a1a]">GenFlow.ai</h2>
          </div>

          {/* Heading */}
          <h1 className="text-center text-[#1a1a1a] text-[20px] font-normal mb-2">
            Set new password
          </h1>
          <p className="text-center text-[14px] text-[#6b6b6b] mb-8">
            Enter your new password below
          </p>

          {/* Form */}
          <form onSubmit={handlePasswordReset} className="space-y-4 mb-6">
            <div>
              <Label htmlFor="new-password" className="text-[14px] text-[#1a1a1a] font-medium mb-2 block">
                New password
              </Label>
              <div className="relative">
                <Input
                  id="new-password"
                  type={showNewPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  required
                  minLength={8}
                  className="h-11 bg-white border-[#e0e0e0] focus:border-[#5865f2] focus:ring-[#5865f2] pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowNewPassword(!showNewPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6b6b6b] hover:text-[#1a1a1a] transition-colors"
                >
                  {showNewPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
              <p className="text-[12px] text-[#6b6b6b] mt-1">Must be at least 8 characters</p>
            </div>

            <div>
              <Label htmlFor="confirm-password" className="text-[14px] text-[#1a1a1a] font-medium mb-2 block">
                Confirm password
              </Label>
              <div className="relative">
                <Input
                  id="confirm-password"
                  type={showConfirmPassword ? 'text' : 'password'}
                  placeholder="••••••••"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  required
                  minLength={8}
                  className="h-11 bg-white border-[#e0e0e0] focus:border-[#5865f2] focus:ring-[#5865f2] pr-10"
                />
                <button
                  type="button"
                  onClick={() => setShowConfirmPassword(!showConfirmPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-[#6b6b6b] hover:text-[#1a1a1a] transition-colors"
                >
                  {showConfirmPassword ? (
                    <EyeOff className="w-5 h-5" />
                  ) : (
                    <Eye className="w-5 h-5" />
                  )}
                </button>
              </div>
            </div>

            <Button
              type="submit"
              className="w-full h-12 bg-[#5865f2] hover:bg-[#4752c4] text-white rounded-md"
            >
              Reset password
            </Button>
          </form>
        </div>
      </div>
    );
  }

  if (isSubmitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-[#fafafa] p-4 relative">
        {/* Back Button - Top Left */}
        <button
          onClick={onBack}
          className="absolute top-8 left-8 flex items-center gap-2 text-[#6b6b6b] hover:text-[#1a1a1a] transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          <span className="text-[14px]">Back to login</span>
        </button>

        <div className="w-full max-w-[400px]">
          {/* Logo */}
          <div className="flex justify-center mb-4">
            <div className="w-14 h-14 bg-[#1a1a1a] rounded-full flex items-center justify-center">
              <svg
                className="w-7 h-7 text-white"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                viewBox="0 0 24 24"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z"
                />
              </svg>
            </div>
          </div>

          {/* Platform Name */}
          <div className="text-center mb-8">
            <h2 className="text-[18px] font-medium text-[#1a1a1a]">GenFlow.ai</h2>
          </div>

          {/* Success Message */}
          <div className="text-center mb-8">
            <h1 className="text-[20px] font-normal text-[#1a1a1a] mb-3">
              Check your email
            </h1>
            <p className="text-[14px] text-[#6b6b6b] mb-2">
              We've sent a password reset link to
            </p>
            <p className="text-[14px] font-medium text-[#1a1a1a] mb-4">{email}</p>
            <p className="text-[13px] text-[#6b6b6b]">
              Didn't receive the email?{' '}
              <button
                onClick={() => setIsSubmitted(false)}
                className="text-[#5865f2] hover:underline"
              >
                Try again
              </button>
            </p>
          </div>

          <Button
            onClick={onBack}
            className="w-full h-12 bg-[#5865f2] hover:bg-[#4752c4] text-white rounded-md mb-4"
          >
            Back to login
          </Button>

          {/* Skip to password reset (for demo/testing) */}
          <button
            onClick={() => setShowResetForm(true)}
            className="w-full text-[13px] text-[#6b6b6b] hover:text-[#1a1a1a] underline"
          >
            Skip to password reset (demo)
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-[#fafafa] p-4 relative">
      {/* Back Button - Top Left */}
      <button
        onClick={onBack}
        className="absolute top-8 left-8 flex items-center gap-2 text-[#6b6b6b] hover:text-[#1a1a1a] transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        <span className="text-[14px]">Back to login</span>
      </button>

      <div className="w-full max-w-[400px]">
        {/* Logo */}
        <div className="flex justify-center mb-4">
          <div className="w-14 h-14 bg-[#1a1a1a] rounded-full flex items-center justify-center">
            <svg className="w-7 h-7 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
          </div>
        </div>

        {/* Platform Name */}
        <div className="text-center mb-8">
          <h2 className="text-[18px] font-medium text-[#1a1a1a]">GenFlow.ai</h2>
        </div>

        {/* Heading */}
        <h1 className="text-center text-[#1a1a1a] text-[20px] font-normal mb-2">
          Reset your password
        </h1>
        <p className="text-center text-[14px] text-[#6b6b6b] mb-8">
          Enter your email address and we'll send you a link to reset your password
        </p>

        {/* Form */}
        <form onSubmit={handleSubmit} className="space-y-4 mb-6">
          <div>
            <Label htmlFor="email" className="text-[14px] text-[#1a1a1a] font-medium mb-2 block">
              Email
            </Label>
            <Input
              id="email"
              type="email"
              placeholder="you@example.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="h-11 bg-white border-[#e0e0e0] focus:border-[#5865f2] focus:ring-[#5865f2]"
            />
          </div>

          <Button
            type="submit"
            className="w-full h-12 bg-[#5865f2] hover:bg-[#4752c4] text-white rounded-md"
          >
            Send reset link
          </Button>
        </form>

        {/* Back to Login */}
        <p className="text-center text-[14px] text-[#6b6b6b]">
          Remember your password?{' '}
          <button
            onClick={onBack}
            className="text-[#1a1a1a] hover:underline font-medium"
          >
            Log in
          </button>
        </p>
      </div>
    </div>
  );
}
import { useState } from 'react';
import { 
  Home, 
  Sparkles, 
  Image as ImageIcon,
  Video,
  FolderOpen,
  Settings, 
  User,
  LogOut,
  ChevronDown,
  ChevronRight,
  Search,
  Bell,
  Plus,
  MoreHorizontal,
  Ticket,
  GraduationCap,
  LifeBuoy,
  Rocket,
  MessageSquare,
  Wand2,
  Film,
  Maximize,
  Crop,
  Layers,
  PanelLeftClose,
  PanelLeftOpen,
  Pen,
  ArrowRight,
  Zap,
  Settings2,
  FolderPlus,
  BookOpen,
  Folder,
  X,
  Info,
  Upload,
  ArrowLeftRight,
  BarChart3,
  Menu
} from 'lucide-react';
import { toast } from 'sonner';
import { Settings as SettingsPage } from '@/app/components/settings';
import { ImagePlayground } from '@/app/components/image-playground';
import { VideoPlayground } from '@/app/components/video-playground';
import { CreateTeamModal } from '@/app/components/create-team-modal';
import { InviteMemberModal } from '@/app/components/invite-member-modal';
import { AssetLibraryPage } from '@/app/components/asset-library-page';
import { GoogleIcon } from '@/app/components/google-icon';
import virtualTryonImage from 'figma:asset/279dfad8d76f4f07dbe5f807702e648501865793.png';
import productInSceneImage from 'figma:asset/e0073c7d8e45292fa4c16272f2348dc719013393.png';

interface Team {
  id: string;
  name: string;
  description: string;
  type: 'personal' | 'team';
  avatar?: string;
}

interface TeamMember {
  id: string;
  email: string;
  name: string;
  role: 'owner' | 'admin' | 'member' | 'viewer';
  status: 'active' | 'pending';
  joinedAt: string;
}

interface DashboardProps {
  onLogout: () => void;
  userEmail?: string;
}

export function Dashboard({ onLogout, userEmail = 'user@example.com' }: DashboardProps) {
  const [activeMenu, setActiveMenu] = useState('home');
  const [expandedMenus, setExpandedMenus] = useState<string[]>(['playground', 'product-studio']);
  const [showProfileDropdown, setShowProfileDropdown] = useState(false);
  const [showWorkspaceDropdown, setShowWorkspaceDropdown] = useState(false);
  const [showMoreMenu, setShowMoreMenu] = useState(false);
  const [selectedMode, setSelectedMode] = useState('image');
  const [prompt, setPrompt] = useState('');
  const [selectedTab, setSelectedTab] = useState<'image' | 'video'>('image');
  const [isPromptFocused, setIsPromptFocused] = useState(false);
  const [showImagePlayground, setShowImagePlayground] = useState(false);
  const [showVideoPlayground, setShowVideoPlayground] = useState(false);
  const [settingsTab, setSettingsTab] = useState<'profile' | 'members' | 'billing'>('profile');
  const [isMobileSidebarOpen, setIsMobileSidebarOpen] = useState(false);
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);
  
  // Team Management State
  const [teams, setTeams] = useState<Team[]>([
    {
      id: '1',
      name: userEmail.split('@')[0],
      description: 'Personal workspace',
      type: 'personal'
    }
  ]);
  const [currentTeam, setCurrentTeam] = useState<Team>(teams[0]);
  const [showCreateTeamModal, setShowCreateTeamModal] = useState(false);
  const [showInviteMemberModal, setShowInviteMemberModal] = useState(false);
  const [teamMembers, setTeamMembers] = useState<{ [teamId: string]: TeamMember[] }>({
    '1': [
      {
        id: '1',
        email: userEmail,
        name: userEmail.split('@')[0],
        role: 'owner',
        status: 'active',
        joinedAt: new Date().toISOString()
      }
    ]
  });
  
  // Media Modal State
  const [showMediaModal, setShowMediaModal] = useState(false);
  const [selectedMediaTab, setSelectedMediaTab] = useState<'uploads' | 'generations' | 'collections'>('uploads');
  const [selectedMediaCount, setSelectedMediaCount] = useState(0);
  const [uploadedImages, setUploadedImages] = useState<Array<{id: string; url: string; name: string}>>([]);
  const [selectedImages, setSelectedImages] = useState<Set<string>>(new Set());
  const [modalType, setModalType] = useState<'start' | 'end' | null>(null);
  const [startFrameImage, setStartFrameImage] = useState<{id: string; url: string; name: string} | null>(null);
  const [endFrameImage, setEndFrameImage] = useState<{id: string; url: string; name: string} | null>(null);
  
  // Quick settings state
  const [selectedAspectRatio, setSelectedAspectRatio] = useState('1:1');
  const [selectedModel, setSelectedModel] = useState('Nano banana');
  const [selectedDuration, setSelectedDuration] = useState('5s');
  const [showAspectRatioDropdown, setShowAspectRatioDropdown] = useState(false);
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const [showDurationDropdown, setShowDurationDropdown] = useState(false);

  const handleGenerate = () => {
    if (!prompt.trim()) return;

    // Redirect to appropriate playground based on selected tab
    if (selectedTab === 'image') {
      setShowImagePlayground(true);
    } else {
      setShowVideoPlayground(true);
    }
  };

  const toggleMenu = (menuId: string) => {
    if (expandedMenus.includes(menuId)) {
      setExpandedMenus(expandedMenus.filter(id => id !== menuId));
    } else {
      setExpandedMenus([...expandedMenus, menuId]);
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    const newImages: Array<{id: string; url: string; name: string}> = [];
    
    Array.from(files).forEach((file) => {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          newImages.push({
            id: `${Date.now()}-${Math.random()}`,
            url: result,
            name: file.name
          });
          
          // Update state after all files are processed
          if (newImages.length === files.length) {
            setUploadedImages([...uploadedImages, ...newImages]);
          }
        };
        reader.readAsDataURL(file);
      }
    });
  };

  const toggleImageSelection = (imageId: string) => {
    const newSelected = new Set(selectedImages);
    if (newSelected.has(imageId)) {
      newSelected.delete(imageId);
    } else {
      // Only allow one image for start/end frame
      newSelected.clear();
      newSelected.add(imageId);
    }
    setSelectedImages(newSelected);
    setSelectedMediaCount(newSelected.size);
  };

  const handleConfirmImages = () => {
    const selected = uploadedImages.filter(img => selectedImages.has(img.id));
    if (selected.length > 0) {
      if (modalType === 'start') {
        setStartFrameImage(selected[0]);
      } else if (modalType === 'end') {
        setEndFrameImage(selected[0]);
      }
    }
    setShowMediaModal(false);
    setSelectedImages(new Set());
    setSelectedMediaCount(0);
    setModalType(null);
  };

  const removeStartFrame = () => {
    setStartFrameImage(null);
  };

  const removeEndFrame = () => {
    setEndFrameImage(null);
  };

  // Team Management Functions
  const handleCreateTeam = (teamName: string, teamDescription: string) => {
    const newTeam: Team = {
      id: Date.now().toString(),
      name: teamName,
      description: teamDescription,
      type: 'team'
    };
    
    setTeams([...teams, newTeam]);
    
    // Add current user as owner of the new team
    setTeamMembers({
      ...teamMembers,
      [newTeam.id]: [
        {
          id: '1',
          email: userEmail,
          name: userEmail.split('@')[0],
          role: 'owner',
          status: 'active',
          joinedAt: new Date().toISOString()
        }
      ]
    });
    
    // Switch to the new team
    setCurrentTeam(newTeam);
    setShowCreateTeamModal(false);
    
    // Show success notification
    toast.success(`Team "${teamName}" created successfully!`);
  };

  const handleSwitchTeam = (team: Team) => {
    setCurrentTeam(team);
    setShowProfileDropdown(false);
  };

  const handleInviteMember = (email: string, role: 'admin' | 'member' | 'viewer') => {
    const currentMembers = teamMembers[currentTeam.id] || [];
    
    // Check if member already exists
    if (currentMembers.some(m => m.email === email)) {
      toast.error('This member is already part of the team');
      return;
    }
    
    const newMember: TeamMember = {
      id: Date.now().toString(),
      email: email,
      name: email.split('@')[0],
      role: role,
      status: 'pending',
      joinedAt: new Date().toISOString()
    };
    
    setTeamMembers({
      ...teamMembers,
      [currentTeam.id]: [...currentMembers, newMember]
    });
    
    setShowInviteMemberModal(false);
    
    // Show success notification
    toast.success(`Invitation sent to ${email}`);
  };

  const handleRemoveMember = (memberId: string) => {
    const currentMembers = teamMembers[currentTeam.id] || [];
    setTeamMembers({
      ...teamMembers,
      [currentTeam.id]: currentMembers.filter(m => m.id !== memberId)
    });
  };

  const handleUpdateMemberRole = (memberId: string, newRole: 'admin' | 'member' | 'viewer') => {
    const currentMembers = teamMembers[currentTeam.id] || [];
    setTeamMembers({
      ...teamMembers,
      [currentTeam.id]: currentMembers.map(m => 
        m.id === memberId ? { ...m, role: newRole } : m
      )
    });
  };

  const menuItems = [
    { 
      id: 'home', 
      label: 'Home', 
      icon: Home 
    },
    { 
      id: 'asset-library', 
      label: 'Asset Library', 
      icon: FolderOpen
    },
    { 
      id: 'playground', 
      label: 'Playground', 
      icon: Sparkles,
      submenus: [
        { id: 'playground-image', label: 'Image', icon: ImageIcon },
        { id: 'playground-video', label: 'Video', icon: Video },
      ]
    },
    { 
      id: 'product-studio', 
      label: 'Studio', 
      icon: FolderOpen,
      submenus: [
        { id: 'product-ugc-video', label: 'UGC Video', icon: Video },
        { id: 'product-virtual-tryon', label: 'Virtual Tryon', icon: User },
        { id: 'product-in-scene', label: 'Product in Scene', icon: ImageIcon },
        { id: 'product-video', label: 'Product Video', icon: Video },
        { id: 'product-descriptions', label: 'Product Descriptions', icon: MessageSquare },
      ]
    },
  ];

  const workspaceCards = [
    {
      id: 1,
      title: 'AI Content Generator',
      description: 'Create engaging content with AI-powered tools',
      icon: '✨',
      color: '#e8f0ff',
    },
    {
      id: 2,
      title: 'Workflow Builder',
      description: 'Design and automate your creative workflows',
      icon: '🔄',
      color: '#ffe8f0',
    },
    {
      id: 3,
      title: 'Asset Library',
      description: 'Manage and organize your creative assets',
      icon: '📁',
      color: '#f0ffe8',
    },
    {
      id: 4,
      title: 'Team Collaboration',
      description: 'Work together with your team in real-time',
      icon: '👥',
      color: '#fff4e8',
    },
  ];

  const getGreeting = () => {
    const hour = new Date().getHours();
    if (hour < 12) return 'Good morning';
    if (hour < 18) return 'Good afternoon';
    return 'Good evening';
  };

  const creationModes = [
    { id: 'image', label: 'Image', icon: ImageIcon },
    { id: 'video', label: 'Video', icon: Video },
    { id: 'blueprints', label: 'Blueprints', icon: Layers, isNew: true },
    { id: 'flow-state', label: 'Flow State', icon: Sparkles },
    { id: 'upscaler', label: 'Upscaler', icon: Maximize },
    { id: 'canvas', label: 'Canvas', icon: Crop },
    { id: 'draw', label: 'Draw', icon: Pen },
  ];

  const featuredStudios = [
    {
      id: 1,
      title: 'UGC Video',
      description: 'Create authentic user-generated content videos',
      image: 'https://images.unsplash.com/photo-1655199798109-08ff7497e748?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx1Z2MlMjB2aWRlbyUyMGNyZWF0b3IlMjBpbmZsdWVuY2VyfGVufDF8fHx8MTc3MDAwODA2NXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: 2,
      title: 'Virtual Tryon',
      description: 'Visualize products on AI models or upload your own images',
      image: virtualTryonImage,
    },
    {
      id: 3,
      title: 'Product in Scene',
      description: 'Place your products in beautiful lifestyle scenes and environments',
      image: productInSceneImage,
    },
    {
      id: 4,
      title: 'Product Video',
      description: 'Generate dynamic product videos for social media and ads',
      image: 'https://images.unsplash.com/photo-1668609045515-ebf86dd88c8e?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxwcm9kdWN0JTIwdmlkZW8lMjBjb21tZXJjaWFsJTIwc3R1ZGlvfGVufDF8fHx8MTc3MDAwODA2N3ww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
    {
      id: 5,
      title: 'Product Descriptions',
      description: 'AI-powered compelling product copy and descriptions',
      image: 'https://images.unsplash.com/photo-1758874385949-cec80d549f67?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3cml0aW5nJTIwY29udGVudCUyMGxhcHRvcCUyMG5vdGVib29rfGVufDF8fHx8MTc3MDAwODA3MHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    },
  ];

  return (
    <div className="min-h-screen flex">
      {activeMenu === 'settings' ? (
        <SettingsPage 
          userEmail={userEmail} 
          onBack={() => setActiveMenu('home')}
          currentTeam={currentTeam}
          teamMembers={teamMembers[currentTeam.id] || []}
          onInviteMember={() => setShowInviteMemberModal(true)}
          onRemoveMember={handleRemoveMember}
          onUpdateMemberRole={handleUpdateMemberRole}
          initialTab={settingsTab}
        />
      ) : showImagePlayground ? (
        <div className="flex-1">
          <ImagePlayground userEmail={userEmail} onBack={() => setShowImagePlayground(false)} />
        </div>
      ) : showVideoPlayground ? (
        <div className="flex-1">
          <VideoPlayground userEmail={userEmail} onBack={() => setShowVideoPlayground(false)} />
        </div>
      ) : (
        <>
          {/* Mobile Sidebar Overlay */}
          {isMobileSidebarOpen && (
            <div
              className="fixed inset-0 bg-black/50 z-40 md:hidden"
              onClick={() => setIsMobileSidebarOpen(false)}
            />
          )}

          {/* Sidebar */}
          <div className={`
            fixed md:static inset-y-0 left-0 z-50
            ${isSidebarCollapsed ? 'w-20' : 'w-64'} bg-white border-r border-[#e0e0e0] flex flex-col
            transform transition-all duration-300 ease-in-out
            ${isMobileSidebarOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'}
          `}>
            {/* Logo */}
            <div className={`p-6 flex items-center ${isSidebarCollapsed ? 'justify-center' : 'justify-between'}`}>
              {!isSidebarCollapsed && (
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 bg-[#1a1a1a] rounded-lg flex items-center justify-center">
                    <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                    </svg>
                  </div>
                  <span className="font-semibold text-[#1a1a1a]">GenFlow.ai</span>
                </div>
              )}
              {isSidebarCollapsed && (
                <div className="w-8 h-8 bg-[#1a1a1a] rounded-lg flex items-center justify-center">
                  <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
                  </svg>
                </div>
              )}
              {/* Close button for mobile */}
              {!isSidebarCollapsed && (
                <button
                  onClick={() => setIsMobileSidebarOpen(false)}
                  className="md:hidden p-1.5 hover:bg-[#f5f5f5] rounded-lg transition-colors"
                >
                  <X className="w-5 h-5 text-[#6b6b6b]" />
                </button>
              )}
            </div>

            {/* Navigation */}
            <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
              {menuItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeMenu === item.id;
                const isExpanded = expandedMenus.includes(item.id);
                const hasSubmenus = item.submenus && item.submenus.length > 0;

                return (
                  <div key={item.id}>
                    <button
                      onClick={() => {
                        if (hasSubmenus) {
                          toggleMenu(item.id);
                        } else {
                          setActiveMenu(item.id);
                          setIsMobileSidebarOpen(false);
                        }
                      }}
                      className={`w-full flex items-center ${isSidebarCollapsed ? 'justify-center' : 'justify-between'} px-3 py-2.5 rounded-lg transition-colors ${
                        isActive
                          ? 'bg-transparent text-[#0000FF]'
                          : 'text-[#6b6b6b] hover:bg-[#f5f5f5] hover:text-[#1a1a1a]'
                      }`}
                      title={isSidebarCollapsed ? item.label : undefined}
                    >
                      <div className={`flex items-center ${isSidebarCollapsed ? '' : 'gap-3'}`}>
                        <Icon className="w-5 h-5" strokeWidth={1.5} />
                        {!isSidebarCollapsed && <span className="text-[14px] font-medium">{item.label}</span>}
                      </div>
                      {hasSubmenus && !isSidebarCollapsed && (
                        <ChevronRight 
                          className={`w-4 h-4 transition-transform ${isExpanded ? 'rotate-90' : ''}`}
                        />
                      )}
                    </button>

                    {/* Submenus */}
                    {hasSubmenus && isExpanded && !isSidebarCollapsed && (
                      <div className="mt-1 ml-4 space-y-1">
                        {item.submenus?.map((submenu) => {
                          const SubIcon = submenu.icon;
                          const isSubmenuActive = activeMenu === submenu.id;
                          return (
                            <button
                              key={submenu.id}
                              onClick={() => {
                                if (submenu.id === 'playground-image') {
                                  setShowImagePlayground(true);
                                  setIsMobileSidebarOpen(false);
                                } else if (submenu.id === 'playground-video') {
                                  setShowVideoPlayground(true);
                                  setIsMobileSidebarOpen(false);
                                } else {
                                  setActiveMenu(submenu.id);
                                  setIsMobileSidebarOpen(false);
                                }
                              }}
                              className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg transition-colors text-[13px] ${
                                isSubmenuActive
                                  ? 'bg-[#e8f0ff] text-[#0000FF]'
                                  : 'text-[#6b6b6b] hover:bg-[#f5f5f5] hover:text-[#1a1a1a]'
                              }`}
                            >
                              <SubIcon className="w-4 h-4" />
                              <span className="font-medium">{submenu.label}</span>
                            </button>
                          );
                        })}
                      </div>
                    )}
                  </div>
                );
              })}

              {/* More */}
              {/* Hidden for now
              <button
                onClick={() => setShowMoreMenu(!showMoreMenu)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                  activeMenu === 'more'
                    ? 'bg-[#0000FF] text-white'
                    : 'text-[#6b6b6b] hover:bg-[#f5f5f5] hover:text-[#1a1a1a]'
                }`}
              >
                <MoreHorizontal className="w-5 h-5" />
                <span className="text-[14px] font-medium">More</span>
              </button>

              {showMoreMenu && (
                <div className="absolute left-full ml-2 bottom-32 w-[280px] bg-white border border-[#e0e0e0] rounded-lg shadow-lg overflow-hidden z-50">
                  <button className="w-full flex items-start gap-3 px-4 py-3 hover:bg-[#f5f5f5] transition-colors text-left">
                    <GraduationCap className="w-5 h-5 text-[#6b6b6b] mt-0.5 flex-shrink-0" />
                    <div>
                      <h3 className="text-[14px] font-medium text-[#1a1a1a] mb-0.5">Learn</h3>
                      <p className="text-[12px] text-[#6b6b6b]">Explore tutorials and walkthroughs</p>
                    </div>
                  </button>

                  <button className="w-full flex items-start gap-3 px-4 py-3 hover:bg-[#f5f5f5] transition-colors text-left">
                    <LifeBuoy className="w-5 h-5 text-[#6b6b6b] mt-0.5 flex-shrink-0" />
                    <div>
                      <h3 className="text-[14px] font-medium text-[#1a1a1a] mb-0.5">FAQ and Help</h3>
                      <p className="text-[12px] text-[#6b6b6b]">Find answers and get support</p>
                    </div>
                  </button>

                  <button className="w-full flex items-start gap-3 px-4 py-3 hover:bg-[#f5f5f5] transition-colors text-left">
                    <Rocket className="w-5 h-5 text-[#6b6b6b] mt-0.5 flex-shrink-0" />
                    <div>
                      <h3 className="text-[14px] font-medium text-[#1a1a1a] mb-0.5">What's New</h3>
                      <p className="text-[12px] text-[#6b6b6b]">See the latest features</p>
                    </div>
                  </button>

                  <button className="w-full flex items-start gap-3 px-4 py-3 hover:bg-[#f5f5f5] transition-colors text-left">
                    <MessageSquare className="w-5 h-5 text-[#6b6b6b] mt-0.5 flex-shrink-0" />
                    <div>
                      <h3 className="text-[14px] font-medium text-[#1a1a1a] mb-0.5">Feedback</h3>
                      <p className="text-[12px] text-[#6b6b6b]">Share ideas and report issues</p>
                    </div>
                  </button>
                </div>
              )}
              */}
            </nav>

            {/* Settings - Bottom of Sidebar */}
            <div className="p-3 border-t border-[#e0e0e0]">
              <button
                onClick={() => {
                  setSettingsTab('profile');
                  setActiveMenu('settings');
                  setIsMobileSidebarOpen(false);
                }}
                className={`w-full flex items-center ${isSidebarCollapsed ? 'justify-center' : 'gap-3'} px-3 py-2.5 rounded-lg transition-colors ${
                  activeMenu === 'settings'
                    ? 'bg-transparent text-[#0000FF]'
                    : 'text-[#6b6b6b] hover:bg-[#f5f5f5] hover:text-[#1a1a1a]'
                }`}
                title={isSidebarCollapsed ? 'Settings' : undefined}
              >
                <Settings className="w-5 h-5" />
                {!isSidebarCollapsed && <span className="text-[14px] font-medium">Settings</span>}
              </button>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 flex flex-col">
            {/* Top Bar */}
            <div className="bg-white px-4 md:px-8 py-3.5 flex items-center justify-between gap-3 border-b border-[#e0e0e0]">
              {/* Left Side: Hamburger + Collapse Toggle + Page Title */}
              <div className="flex items-center gap-3">
                {/* Hamburger Menu for Mobile */}
                <button
                  onClick={() => setIsMobileSidebarOpen(true)}
                  className="md:hidden p-1.5 hover:bg-[#f5f5f5] rounded-lg transition-colors"
                >
                  <Menu className="w-5 h-5 text-[#6b6b6b]" />
                </button>

                {/* Sidebar Collapse Toggle - Desktop Only */}
                <button
                  onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
                  className="hidden md:block p-1.5 hover:bg-[#f5f5f5] rounded-lg transition-colors"
                  title={isSidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
                >
                  {isSidebarCollapsed ? (
                    <PanelLeftOpen className="w-5 h-5 text-[#6b6b6b]" />
                  ) : (
                    <PanelLeftClose className="w-5 h-5 text-[#6b6b6b]" />
                  )}
                </button>

                {/* Page Title */}
                <h1 className="text-[16px] font-medium text-[#1a1a1a]">
                  {activeMenu === 'home' && 'Home'}
                  {activeMenu === 'asset-library' && 'Asset Library'}
                  {activeMenu === 'playground' && expandedMenu === 'playground' && !showImagePlayground && !showVideoPlayground && 'Playground'}
                  {activeMenu === 'playground' && showImagePlayground && 'Image Playground'}
                  {activeMenu === 'playground' && showVideoPlayground && 'Video Playground'}
                  {activeMenu === 'studio' && 'Studio'}
                  {activeMenu === 'settings' && 'Settings'}
                </h1>
              </div>

              {/* Right Side: Workspace Dropdown + Notification + Profile */}
              <div className="flex items-center gap-2">
                {/* Workspace Dropdown */}
                <div className="relative">
                  <button 
                    onClick={() => setShowWorkspaceDropdown(!showWorkspaceDropdown)}
                    className="flex items-center gap-2 px-3 py-1.5 hover:bg-[#f5f5f5] rounded-lg transition-colors"
                  >
                    <div className="w-7 h-7 bg-[#0000FF] rounded-full flex items-center justify-center text-white font-semibold text-[13px]">
                      {currentTeam.name.charAt(0).toUpperCase()}
                    </div>
                    <span className="hidden md:block text-[14px] font-medium text-[#1a1a1a] max-w-[120px] truncate">
                      {currentTeam.name}
                    </span>
                    <ChevronDown className={`w-4 h-4 text-[#6b6b6b] transition-transform ${showWorkspaceDropdown ? 'rotate-180' : ''}`} />
                  </button>

                  {/* Workspace Dropdown Menu */}
                  {showWorkspaceDropdown && (
                    <>
                      <div
                        className="fixed inset-0 z-40"
                        onClick={() => setShowWorkspaceDropdown(false)}
                      />
                      <div className="absolute right-0 top-full mt-2 w-[280px] bg-white border border-[#e0e0e0] rounded-lg shadow-lg overflow-hidden z-50">
                        {/* User Info */}
                        <div className="px-4 py-3 border-b border-[#e0e0e0]">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-10 bg-[#0000FF] rounded-full flex items-center justify-center text-white font-semibold text-[16px]">
                              {userEmail.charAt(0).toUpperCase()}
                            </div>
                            <div className="flex-1 min-w-0">
                              <p className="text-[14px] text-[#1a1a1a] font-semibold truncate">
                                {userEmail.split('@')[0]}
                              </p>
                              <p className="text-[12px] text-[#6b6b6b] truncate">{userEmail}</p>
                            </div>
                          </div>
                        </div>

                        {/* Current Teams */}
                        <div className="max-h-[200px] overflow-y-auto border-b border-[#e0e0e0]">
                          {teams.map((team) => (
                            <button
                              key={team.id}
                              onClick={() => {
                                handleSwitchTeam(team);
                                setShowWorkspaceDropdown(false);
                              }}
                              className="w-full p-3 hover:bg-[#f5f5f5] transition-colors text-left"
                            >
                              <div className="flex items-center justify-between">
                                <div className="flex items-center gap-3">
                                  <div className="w-10 h-10 bg-[#0000FF] rounded-full flex items-center justify-center text-white font-semibold text-[16px]">
                                    {team.name.charAt(0).toUpperCase()}
                                  </div>
                                  <div>
                                    <p className="text-[14px] text-[#1a1a1a] font-semibold">
                                      {team.name}
                                    </p>
                                    <p className="text-[12px] text-[#6b6b6b] capitalize">{team.type}</p>
                                  </div>
                                </div>
                                {currentTeam.id === team.id && (
                                  <svg className="w-5 h-5 text-[#0000FF]" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                  </svg>
                                )}
                              </div>
                            </button>
                          ))}
                        </div>

                        {/* Create New Team */}
                        <button 
                          onClick={() => {
                            setShowCreateTeamModal(true);
                            setShowWorkspaceDropdown(false);
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#f5f5f5] transition-colors text-left border-b border-[#e0e0e0]"
                        >
                          <div className="w-8 h-8 rounded-full border-2 border-[#0000FF] flex items-center justify-center">
                            <Plus className="w-5 h-5 text-[#0000FF]" />
                          </div>
                          <span className="text-[14px] text-[#1a1a1a] font-medium">Create New Team</span>
                        </button>

                        {/* Usage & Billing */}
                        <button 
                          onClick={() => {
                            setSettingsTab('billing');
                            setActiveMenu('settings');
                            setShowWorkspaceDropdown(false);
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#f5f5f5] transition-colors text-left"
                        >
                          <BarChart3 className="w-5 h-5 text-[#6b6b6b]" />
                          <span className="text-[14px] text-[#1a1a1a]">Usage & Billing</span>
                        </button>

                        {/* Settings */}
                        <button 
                          onClick={() => {
                            setSettingsTab('profile');
                            setActiveMenu('settings');
                            setShowWorkspaceDropdown(false);
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#f5f5f5] transition-colors text-left"
                        >
                          <Settings className="w-5 h-5 text-[#6b6b6b]" />
                          <span className="text-[14px] text-[#1a1a1a]">Settings</span>
                        </button>

                        <div className="border-t border-[#e0e0e0]"></div>

                        {/* Logout */}
                        <button 
                          onClick={() => {
                            setShowWorkspaceDropdown(false);
                            onLogout();
                          }}
                          className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#f5f5f5] transition-colors text-left"
                        >
                          <LogOut className="w-5 h-5 text-[#6b6b6b]" />
                          <span className="text-[14px] text-[#1a1a1a]">Logout</span>
                        </button>
                      </div>
                    </>
                  )}
                </div>
              </div>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-auto">
              {activeMenu === 'asset-library' ? (
                <AssetLibraryPage onOpenImagePlayground={() => setShowImagePlayground(true)} />
              ) : (
                <>
                  {/* Chat Interface */}
                  <div className="flex flex-col items-center justify-center px-4 sm:px-8 py-8 sm:py-12">
                {/* Greeting */}
                <div className="text-center mb-6 sm:mb-8">
                  <h1 className="text-[28px] sm:text-[36px] md:text-[44px] font-bold text-[#1a1a1a] mb-2 sm:mb-3">
                    {getGreeting()}, {userEmail.split('@')[0]}
                  </h1>
                  <p className="text-[16px] sm:text-[19px] text-[#6b6b6b]">
                    What will you like to create today?
                  </p>
                </div>

                {/* Prompt Box with Integrated Tabs */}
                <div className="w-full max-w-4xl mb-12 sm:mb-16">
                  {/* Animated Border Wrapper */}
                  <div className="relative rounded-2xl p-[2px] bg-gradient-to-r from-transparent via-[#0000FF]/40 to-transparent animate-border-flow">
                    <div className={`bg-white backdrop-blur-sm rounded-2xl shadow-lg transition-all relative z-10 ${isPromptFocused ? 'p-4 sm:p-6' : 'p-3 sm:p-4'}`}>
                      {/* Upload Button Row - Only show when focused */}
                      {isPromptFocused && (selectedTab === 'image' || selectedTab === 'video') && (
                        <div className="mb-3 flex flex-wrap items-center gap-2">
                          {/* Image Reference Button - Only show for Image tab */}
                          {selectedTab === 'image' && (
                            <button 
                              onMouseDown={(e) => e.preventDefault()} // Prevent blur on input
                              onClick={() => {
                                setShowMediaModal(true);
                              }}
                              className="flex items-center gap-2.5 px-3.5 py-2.5 bg-[#f8f8f8] hover:bg-[#f0f0f0] border border-[#e0e0e0] rounded-xl transition-colors group relative"
                            >
                              <div className="relative">
                                <ImageIcon className="w-5 h-5 text-[#6b6b6b] group-hover:text-[#1a1a1a]" />
                                <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#0000FF] rounded-full flex items-center justify-center">
                                  <Plus className="w-2 h-2 text-white" />
                                </div>
                                {/* Tooltip on hover */}
                                <div className="absolute bottom-full left-0 mb-2 px-3 py-2 bg-[#1a1a1a] text-white text-[11px] rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-[100]">
                                  Add reference images of a scene, character, or object to guide your generations.
                                  <div className="absolute top-full left-4 -mt-1 border-4 border-transparent border-t-[#1a1a1a]"></div>
                                </div>
                              </div>
                              <span className="text-[12px] sm:text-[13px] font-semibold text-[#1a1a1a]">Image Reference</span>
                            </button>
                          )}
                          
                          {/* Start Frame and End Frame Buttons - Only show for Video tab */}
                          {selectedTab === 'video' && (
                            <>
                              {!startFrameImage && (
                                <button 
                                  onMouseDown={(e) => e.preventDefault()} // Prevent blur on input
                                  onClick={() => {
                                    setModalType('start');
                                    setShowMediaModal(true);
                                  }}
                                className="flex items-center gap-2.5 px-3.5 py-2.5 bg-[#f8f8f8] hover:bg-[#f0f0f0] border border-[#e0e0e0] rounded-xl transition-colors group relative"
                              >
                                <div className="relative">
                                  <ImageIcon className="w-5 h-5 text-[#6b6b6b] group-hover:text-[#1a1a1a]" />
                                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#0000FF] rounded-full flex items-center justify-center">
                                    <Plus className="w-2 h-2 text-white" />
                                  </div>
                                  {/* Tooltip on hover */}
                                  <div className="absolute bottom-full left-0 mb-2 px-3 py-2 bg-[#1a1a1a] text-white text-[11px] rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-[100]">
                                    Select an image to set as the starting frame for your video.
                                    <div className="absolute top-full left-4 -mt-1 border-4 border-transparent border-t-[#1a1a1a]"></div>
                                  </div>
                                </div>
                                <span className="text-[13px] font-semibold text-[#1a1a1a]">Start Frame</span>
                              </button>
                              )}
                              {/* Arrow Icon */}
                              {(!startFrameImage || !endFrameImage) && (
                                <div className="flex items-center justify-center px-2">
                                  <ArrowLeftRight className="w-5 h-5 text-[#9b9b9b]" />
                                </div>
                              )}
                              {!endFrameImage && (
                                <button 
                                  onMouseDown={(e) => e.preventDefault()} // Prevent blur on input
                                  onClick={() => {
                                    setModalType('end');
                                    setShowMediaModal(true);
                                  }}
                                className="flex items-center gap-2.5 px-3.5 py-2.5 bg-[#f8f8f8] hover:bg-[#f0f0f0] border border-[#e0e0e0] rounded-xl transition-colors group relative"
                              >
                                <div className="relative">
                                  <ImageIcon className="w-5 h-5 text-[#6b6b6b] group-hover:text-[#1a1a1a]" />
                                  <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#0000FF] rounded-full flex items-center justify-center">
                                    <Plus className="w-2 h-2 text-white" />
                                  </div>
                                  {/* Tooltip on hover */}
                                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 bg-[#1a1a1a] text-white text-[11px] rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-[100]">
                                    Select an image to set as the ending frame for your video.
                                    <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-[#1a1a1a]"></div>
                                  </div>
                                </div>
                                <span className="text-[13px] font-semibold text-[#1a1a1a]">End Frame</span>
                              </button>
                              )}
                            </>
                          )}
                        </div>
                      )}

                      {/* Confirmed Images Display */}
                      {(startFrameImage || endFrameImage) && (
                        <div className="mb-3 flex items-center gap-2 flex-wrap">
                          {startFrameImage && (
                            <div className="relative group">
                              <div className="w-16 h-16 rounded-lg overflow-hidden border-2 border-[#0000FF] bg-white shadow-sm">
                                <img 
                                  src={startFrameImage.url} 
                                  alt={startFrameImage.name}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              {/* Label */}
                              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-[#0000FF] text-white text-[9px] font-semibold rounded whitespace-nowrap">
                                Start
                              </div>
                              {/* Remove button */}
                              <button
                                onClick={() => removeStartFrame()}
                                className="absolute -top-2 -right-2 w-5 h-5 bg-[#ff0000] rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
                              >
                                <X className="w-3 h-3 text-white" />
                              </button>
                            </div>
                          )}
                          {/* Arrow between images */}
                          {startFrameImage && endFrameImage && (
                            <div className="flex items-center justify-center px-2">
                              <ArrowLeftRight className="w-5 h-5 text-[#9b9b9b]" />
                            </div>
                          )}
                          {endFrameImage && (
                            <div className="relative group">
                              <div className="w-16 h-16 rounded-lg overflow-hidden border-2 border-[#0000FF] bg-white shadow-sm">
                                <img 
                                  src={endFrameImage.url} 
                                  alt={endFrameImage.name}
                                  className="w-full h-full object-cover"
                                />
                              </div>
                              {/* Label */}
                              <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-[#0000FF] text-white text-[9px] font-semibold rounded whitespace-nowrap">
                                End
                              </div>
                              {/* Remove button */}
                              <button
                                onClick={() => removeEndFrame()}
                                className="absolute -top-2 -right-2 w-5 h-5 bg-[#ff0000] rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
                              >
                                <X className="w-3 h-3 text-white" />
                              </button>
                            </div>
                          )}
                        </div>
                      )}

                      {/* Input Row */}
                      <div className={`flex items-center gap-3 ${isPromptFocused ? 'mb-4' : ''} relative`}>
                        <input
                          type="text"
                          value={prompt}
                          onChange={(e) => setPrompt(e.target.value)}
                          onFocus={() => setIsPromptFocused(true)}
                          onBlur={() => {
                            if (prompt.trim() === '') {
                              setIsPromptFocused(false);
                            }
                          }}
                          placeholder={!isPromptFocused && !prompt ? '' : 'Type a prompt...'}
                          className="flex-1 bg-transparent text-[14px] sm:text-[16px] text-[#1a1a1a] placeholder:text-[#9b9b9b] focus:outline-none"
                          style={{
                            caretColor: '#1a1a1a'
                          }}
                        />
                        {!isPromptFocused && !prompt && (
                          <div className="absolute left-0 top-1/2 -translate-y-1/2 pointer-events-none text-[#9b9b9b] text-[16px] flex items-center">
                            <span className="inline-block w-[2px] h-[20px] bg-[#9b9b9b] animate-[blink-cursor_1s_step-end_infinite] mr-1"></span>
                            <span>Type a prompt...</span>
                          </div>
                        )}
                        {!isPromptFocused && (
                          <button 
                            onClick={handleGenerate}
                            disabled={!prompt.trim()}
                            className="px-6 py-2 bg-[#0000FF] text-white rounded-lg font-semibold text-[13px] hover:bg-[#0000CC] transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                            Generate
                          </button>
                        )}
                      </div>

                      {/* Bottom Row with Tabs and Actions - Only show when focused */}
                      {isPromptFocused && (
                        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                          {/* Left: Mode Tabs */}
                          <div className="flex items-center gap-2">
                            <button
                              onMouseDown={(e) => e.preventDefault()} // Prevent blur on input
                              onClick={() => {
                                setSelectedTab('image');
                                setSelectedModel('Nano banana');
                              }}
                              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-[12px] sm:text-[13px] font-medium transition-all ${
                                selectedTab === 'image'
                                  ? 'bg-[#f0f0f0] text-[#1a1a1a] border border-[#e0e0e0]'
                                  : 'text-[#6b6b6b] hover:text-[#1a1a1a] hover:bg-[#f8f8f8]'
                              }`}
                            >
                              <ImageIcon className="w-4 h-4" />
                              <span>Image</span>
                            </button>
                            <button
                              onMouseDown={(e) => e.preventDefault()} // Prevent blur on input
                              onClick={() => {
                                setSelectedTab('video');
                                setSelectedModel('Veo 3.1');
                              }}
                              className={`flex items-center gap-2 px-3 sm:px-4 py-2 rounded-lg text-[12px] sm:text-[13px] font-medium transition-all ${
                                selectedTab === 'video'
                                  ? 'bg-[#f0f0f0] text-[#1a1a1a] border border-[#e0e0e0]'
                                  : 'text-[#6b6b6b] hover:text-[#1a1a1a] hover:bg-[#f8f8f8]'
                              }`}
                            >
                              <Video className="w-4 h-4" />
                              <span>Video</span>
                            </button>
                          </div>

                          {/* Right: Quick Edit Icons and Generate Button */}
                          <div className="flex items-center gap-2 justify-end">
                            {/* Aspect Ratio Dropdown - Show for both Image and Video */}
                            <div className="relative">
                              <button
                                onMouseDown={(e) => e.preventDefault()} // Prevent blur on input
                                onClick={() => {
                                  setShowAspectRatioDropdown(!showAspectRatioDropdown);
                                  setShowModelDropdown(false);
                                  setShowDurationDropdown(false);
                                }}
                                className="flex items-center gap-1.5 px-3 py-2 bg-[#f8f8f8] border border-[#e0e0e0] rounded-lg text-[#1a1a1a] text-[13px] font-medium hover:bg-[#f0f0f0] transition-colors"
                              >
                                <Crop className="w-4 h-4" />
                                <span>{selectedAspectRatio}</span>
                                <ChevronDown className="w-3 h-3" />
                              </button>
                              {showAspectRatioDropdown && (
                                <div className="absolute right-0 top-full mt-1 w-32 bg-white border border-[#e0e0e0] rounded-lg shadow-lg z-50">
                                  {selectedTab === 'image' ? (
                                    <>
                                      <button
                                        onClick={() => {
                                          setSelectedAspectRatio('1:1');
                                          setShowAspectRatioDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                      >
                                        1:1
                                      </button>
                                      <button
                                        onClick={() => {
                                          setSelectedAspectRatio('16:9');
                                          setShowAspectRatioDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                      >
                                        16:9
                                      </button>
                                      <button
                                        onClick={() => {
                                          setSelectedAspectRatio('4:3');
                                          setShowAspectRatioDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                      >
                                        4:3
                                      </button>
                                      <button
                                        onClick={() => {
                                          setSelectedAspectRatio('3:4');
                                          setShowAspectRatioDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                      >
                                        3:4
                                      </button>
                                      <button
                                        onClick={() => {
                                          setSelectedAspectRatio('9:16');
                                          setShowAspectRatioDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                      >
                                        9:16
                                      </button>
                                      <button
                                        onClick={() => {
                                          setSelectedAspectRatio('Custom');
                                          setShowAspectRatioDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                      >
                                        Custom
                                      </button>
                                    </>
                                  ) : (
                                    <>
                                      <button
                                        onClick={() => {
                                          setSelectedAspectRatio('9:16');
                                          setShowAspectRatioDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                      >
                                        9:16
                                      </button>
                                      <button
                                        onClick={() => {
                                          setSelectedAspectRatio('16:9');
                                          setShowAspectRatioDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                      >
                                        16:9
                                      </button>
                                      <button
                                        onClick={() => {
                                          setSelectedAspectRatio('1:1');
                                          setShowAspectRatioDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                      >
                                        1:1
                                      </button>
                                      <button
                                        onClick={() => {
                                          setSelectedAspectRatio('Custom');
                                          setShowAspectRatioDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                      >
                                        Custom
                                      </button>
                                    </>
                                  )}
                                </div>
                              )}
                            </div>

                            {/* Model Dropdown - Show for both Image and Video */}
                            <div className="relative">
                              <button
                                onMouseDown={(e) => e.preventDefault()} // Prevent blur on input
                                onClick={() => {
                                  setShowModelDropdown(!showModelDropdown);
                                  setShowAspectRatioDropdown(false);
                                  setShowDurationDropdown(false);
                                }}
                                className="flex items-center gap-1.5 px-3 py-2 bg-[#f8f8f8] border border-[#e0e0e0] rounded-lg text-[#1a1a1a] text-[13px] font-medium hover:bg-[#f0f0f0] transition-colors"
                              >
                                <Wand2 className="w-4 h-4" />
                                <span>{selectedModel}</span>
                                <ChevronDown className="w-3 h-3" />
                              </button>
                              {showModelDropdown && (
                                <div className="absolute right-0 top-full mt-1 w-40 bg-white border border-[#e0e0e0] rounded-lg shadow-lg z-50">
                                  {selectedTab === 'image' ? (
                                    <>
                                      <button
                                        onClick={() => {
                                          setSelectedModel('Auto');
                                          setShowModelDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                      >
                                        Auto
                                      </button>
                                      <button
                                        onClick={() => {
                                          setSelectedModel('Nano banana');
                                          setShowModelDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px] flex items-center justify-between"
                                      >
                                        <span>Nano banana</span>
                                        <GoogleIcon className="w-4 h-4" />
                                      </button>
                                      <button
                                        onClick={() => {
                                          setSelectedModel('Imagen');
                                          setShowModelDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px] flex items-center justify-between"
                                      >
                                        <span>Imagen</span>
                                        <GoogleIcon className="w-4 h-4" />
                                      </button>
                                    </>
                                  ) : (
                                    <>
                                      <button
                                        onClick={() => {
                                          setSelectedModel('Auto');
                                          setShowModelDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                      >
                                        Auto
                                      </button>
                                      <button
                                        onClick={() => {
                                          setSelectedModel('Veo 3.1');
                                          setShowModelDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px] flex items-center justify-between"
                                      >
                                        <span>Veo 3.1</span>
                                        <GoogleIcon className="w-4 h-4" />
                                      </button>
                                      <button
                                        onClick={() => {
                                          setSelectedModel('Veo 3.1 Fast');
                                          setShowModelDropdown(false);
                                        }}
                                        className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px] flex items-center justify-between"
                                      >
                                        <span>Veo 3.1 Fast</span>
                                        <GoogleIcon className="w-4 h-4" />
                                      </button>
                                    </>
                                  )}
                                </div>
                              )}
                            </div>

                            {/* Duration Dropdown - Only show for Video */}
                            {selectedTab === 'video' && (
                              <div className="relative">
                                <button
                                  onMouseDown={(e) => e.preventDefault()} // Prevent blur on input
                                  onClick={() => {
                                    setShowDurationDropdown(!showDurationDropdown);
                                    setShowAspectRatioDropdown(false);
                                    setShowModelDropdown(false);
                                  }}
                                  className="flex items-center gap-1.5 px-3 py-2 bg-[#f8f8f8] border border-[#e0e0e0] rounded-lg text-[#1a1a1a] text-[13px] font-medium hover:bg-[#f0f0f0] transition-colors"
                                >
                                  <Zap className="w-4 h-4" />
                                  <span>{selectedDuration}</span>
                                  <ChevronDown className="w-3 h-3" />
                                </button>
                                {showDurationDropdown && (
                                  <div className="absolute right-0 top-full mt-1 w-24 bg-white border border-[#e0e0e0] rounded-lg shadow-lg z-50">
                                    <button
                                      onClick={() => {
                                        setSelectedDuration('3s');
                                        setShowDurationDropdown(false);
                                      }}
                                      className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                    >
                                      3s
                                    </button>
                                    <button
                                      onClick={() => {
                                        setSelectedDuration('5s');
                                        setShowDurationDropdown(false);
                                      }}
                                      className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                    >
                                      5s
                                    </button>
                                    <button
                                      onClick={() => {
                                        setSelectedDuration('10s');
                                        setShowDurationDropdown(false);
                                      }}
                                      className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                    >
                                      10s
                                    </button>
                                    <button
                                      onClick={() => {
                                        setSelectedDuration('15s');
                                        setShowDurationDropdown(false);
                                      }}
                                      className="w-full px-4 py-2 hover:bg-[#f5f5f5] transition-colors text-left text-[13px]"
                                    >
                                      15s
                                    </button>
                                  </div>
                                )}
                              </div>
                            )}

                            {/* Settings */}
                            <button 
                              onMouseDown={(e) => e.preventDefault()} // Prevent blur on input
                              onClick={() => {
                                // Close all dropdowns first
                                setShowAspectRatioDropdown(false);
                                setShowModelDropdown(false);
                                setShowDurationDropdown(false);
                                
                                if (selectedTab === 'image') {
                                  setShowImagePlayground(true);
                                } else {
                                  setShowVideoPlayground(true);
                                }
                              }}
                              className="flex items-center gap-2 px-3 py-2 bg-[#f8f8f8] border border-[#e0e0e0] rounded-lg text-[#1a1a1a] hover:bg-[#f0f0f0] transition-colors"
                            >
                              <Settings2 className="w-4 h-4" />
                              <span className="text-[13px] font-medium">More</span>
                            </button>

                            {/* Generate Button */}
                            <button 
                              onClick={handleGenerate}
                              disabled={!prompt.trim()}
                              className="px-6 py-2 bg-[#0000FF] text-white rounded-lg font-semibold text-[13px] hover:bg-[#0000CC] transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                              Generate
                            </button>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                </div>

                {/* Featured Product Studio Section */}
                <div className="w-full max-w-7xl px-4 sm:px-0">
                  {/* Section Header */}
                  <div className="flex items-center justify-between mb-6">
                    <h2 className="text-[20px] sm:text-[24px] md:text-[28px] font-bold text-[#1a1a1a]">
                      Featured <span className="text-[#0000FF]">Product Studio</span>
                    </h2>
                    <button className="flex items-center gap-1 sm:gap-2 text-[#6b6b6b] hover:text-[#0000FF] transition-colors group">
                      <span className="text-[13px] sm:text-[14px] font-medium">View More</span>
                      <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </button>
                  </div>

                  {/* Studio Cards */}
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-3 sm:gap-4">
                    {featuredStudios.map((studio) => (
                      <button
                        key={studio.id}
                        className="group relative aspect-[3/4] rounded-2xl overflow-hidden hover:scale-105 transition-transform duration-300 bg-gray-900"
                      >
                        {/* Background Image */}
                        <img
                          src={studio.image}
                          alt={studio.title}
                          className={`absolute inset-0 w-full h-full ${
                            studio.id === 2 ? 'object-contain' : 'object-cover'
                          } object-center`}
                        />
                        
                        {/* Default Gradient Overlay */}
                        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent group-hover:from-black/90 group-hover:via-black/40 transition-all duration-300"></div>
                        
                        {/* Title (always visible) */}
                        <div className="absolute bottom-0 left-0 right-0 p-4 transition-opacity duration-300 group-hover:opacity-0">
                          <h3 className="text-white text-[14px] font-semibold leading-tight">
                            {studio.title}
                          </h3>
                        </div>

                        {/* Hover Content - Title + Description */}
                        <div className="absolute inset-0 p-4 flex flex-col justify-end opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                          <h3 className="text-white text-[14px] font-semibold leading-tight mb-2">
                            {studio.title}
                          </h3>
                          <p className="text-white/90 text-[12px] leading-snug">
                            {studio.description}
                          </p>
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              </div>
              </>
              )}
            </div>
          </div>

          {/* Select Asset Modal */}
          {showMediaModal && (
            <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100]" onClick={() => setShowMediaModal(false)}>
              <div className="bg-white rounded-2xl w-[90%] max-w-4xl h-[80vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
                {/* Header */}
                <div className="flex items-center justify-between px-6 py-4 border-b border-[#e0e0e0]">
                  <h2 className="text-[20px] font-bold text-[#1a1a1a]">Select Asset</h2>
                  <button 
                    onClick={() => setShowMediaModal(false)}
                    className="p-2 hover:bg-[#f5f5f5] rounded-full transition-colors"
                  >
                    <X className="w-5 h-5 text-[#6b6b6b]"/>
                  </button>
                </div>

                {/* Tabs */}
                <div className="flex items-center gap-1 px-6 py-3 border-b border-[#e0e0e0]">
                  <button 
                    onClick={() => setSelectedMediaTab('uploads')}
                    className={`px-4 py-2 rounded-lg text-[13px] font-medium transition-colors ${
                      selectedMediaTab === 'uploads' 
                        ? 'bg-[#0000FF] text-white' 
                        : 'text-[#6b6b6b] hover:bg-[#f5f5f5]'
                    }`}
                  >
                    Your Uploads
                  </button>
                  <button 
                    onClick={() => setSelectedMediaTab('generations')}
                    className={`px-4 py-2 rounded-lg text-[13px] font-medium transition-colors ${
                      selectedMediaTab === 'generations' 
                        ? 'bg-[#0000FF] text-white' 
                        : 'text-[#6b6b6b] hover:bg-[#f5f5f5]'
                    }`}
                  >
                    Generations
                  </button>
                </div>

                {/* Content Area */}
                <div className="flex-1 overflow-auto p-6">
                  {selectedMediaTab === 'uploads' && (
                    <>
                      {uploadedImages.length === 0 ? (
                        <div className="flex flex-col items-center justify-center h-full">
                          <label htmlFor="file-upload" className="w-48 h-48 border-2 border-dashed border-[#e0e0e0] rounded-2xl flex flex-col items-center justify-center gap-4 hover:border-[#0000FF] hover:bg-[#0000FF]/5 transition-all cursor-pointer">
                            <div className="w-16 h-16 bg-[#f5f5f5] rounded-full flex items-center justify-center">
                              <Upload className="w-8 h-8 text-[#6b6b6b]"/>
                            </div>
                            <div className="text-center">
                              <p className="text-[14px] font-medium text-[#1a1a1a] mb-1">Upload an image</p>
                              <p className="text-[12px] text-[#6b6b6b]">PNG, JPG or WEBP up to 5MB</p>
                            </div>
                          </label>
                          <input 
                            type="file" 
                            multiple 
                            accept="image/*" 
                            className="hidden" 
                            id="file-upload" 
                            onChange={handleFileUpload}
                          />
                        </div>
                      ) : (
                        <div className="grid grid-cols-3 gap-4">
                          {/* Upload Square - First Item */}
                          <label htmlFor="file-upload-add" className="border-2 border-dashed border-[#e0e0e0] rounded-2xl flex flex-col items-center justify-center gap-4 hover:border-[#0000FF] hover:bg-[#0000FF]/5 transition-all cursor-pointer aspect-square">
                            <div className="w-16 h-16 bg-[#f5f5f5] rounded-full flex items-center justify-center">
                              <Upload className="w-8 h-8 text-[#6b6b6b]"/>
                            </div>
                            <div className="text-center px-4">
                              <p className="text-[14px] font-medium text-[#1a1a1a] mb-1">Upload an image</p>
                              <p className="text-[12px] text-[#6b6b6b]">PNG, JPG or WEBP up to 5MB</p>
                            </div>
                          </label>
                          <input 
                            type="file" 
                            multiple 
                            accept="image/*" 
                            className="hidden" 
                            id="file-upload-add" 
                            onChange={handleFileUpload}
                          />
                          
                          {/* Uploaded Images */}
                          {uploadedImages.map((image) => (
                            <div 
                              key={image.id}
                              className={`relative bg-[#f5f5f5] rounded-lg overflow-hidden aspect-square cursor-pointer transition-all ${
                                selectedImages.has(image.id) ? 'ring-4 ring-[#0000FF]' : ''
                              }`}
                              onClick={() => toggleImageSelection(image.id)}
                            >
                              <img 
                                src={image.url} 
                                alt={image.name}
                                className="w-full h-full object-cover"
                              />
                              {/* Selection Indicator */}
                              {selectedImages.has(image.id) && (
                                <div className="absolute top-3 right-3 w-6 h-6 bg-[#0000FF] rounded-full flex items-center justify-center">
                                  <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                                    <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                                  </svg>
                                </div>
                              )}
                            </div>
                          ))}
                        </div>
                      )}
                    </>
                  )}
                  {selectedMediaTab !== 'uploads' && (
                    <div className="flex items-center justify-center h-full">
                      <p className="text-[14px] text-[#6b6b6b]">No media available</p>
                    </div>
                  )}
                </div>

                {/* Footer */}
                <div className="flex items-center justify-between px-6 py-4 border-t border-[#e0e0e0]">
                  <div className="flex items-center gap-2 text-[13px] text-[#6b6b6b]">
                    <Info className="w-4 h-4 text-[#0000FF]"/>
                    <span>{selectedMediaCount === 1 ? '1 selected' : 'Select 1 image'}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <button 
                      onClick={() => setShowMediaModal(false)}
                      className="px-6 py-2 border border-[#e0e0e0] rounded-lg text-[13px] font-medium text-[#1a1a1a] hover:bg-[#f5f5f5] transition-colors"
                    >
                      Cancel
                    </button>
                    <button 
                      className="px-6 py-2 bg-[#0000FF] text-white rounded-lg text-[13px] font-medium hover:bg-[#0000CC] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                      disabled={selectedMediaCount === 0}
                      onClick={handleConfirmImages}
                    >
                      Confirm
                    </button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </>
      )}

      {/* Team Management Modals */}
      {showCreateTeamModal && (
        <CreateTeamModal
          onClose={() => setShowCreateTeamModal(false)}
          onCreateTeam={handleCreateTeam}
        />
      )}

      {showInviteMemberModal && (
        <InviteMemberModal
          onClose={() => setShowInviteMemberModal(false)}
          onInviteMember={handleInviteMember}
          teamName={currentTeam.name}
        />
      )}
    </div>
  );
}
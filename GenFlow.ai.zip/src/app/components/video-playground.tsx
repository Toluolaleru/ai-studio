import { useState } from 'react';
import {
  ChevronDown,
  Info,
  Search,
  Folder,
  Plus,
  ExternalLink,
  RotateCcw,
  Sparkles,
  X,
  Zap,
  ArrowLeft,
  Ticket,
  Video as VideoIcon,
  Image as ImageIcon,
  Crop,
  MoreVertical,
  Download,
  Share2,
  Trash2,
  Copy,
  Upload,
  Eye,
  EyeOff,
  ArrowLeftRight,
  Maximize2
} from 'lucide-react';
import { IterateModal } from '@/app/components/iterate-modal';
import { GoogleIcon } from '@/app/components/google-icon';

interface VideoPlaygroundProps {
  userEmail: string;
  onBack?: () => void;
}

interface Generation {
  id: string;
  type: 'video';
  prompt: string;
  images: string[]; // Changed from imageUrl to images array for video thumbnails
  model: string;
  dimensions: string;
  speed: string;
  resolution: string;
  timestamp: Date;
}

export function VideoPlayground({ userEmail, onBack }: VideoPlaygroundProps) {
  const [model, setModel] = useState('Veo 3.1');
  const [showModelDropdown, setShowModelDropdown] = useState(false);
  const [selectedAspectRatio, setSelectedAspectRatio] = useState('16:9');
  const [videoDuration, setVideoDuration] = useState(5);
  const [selectedTab, setSelectedTab] = useState<'image' | 'video' | 'flowstate' | 'blueprints'>('video');
  const [prompt, setPrompt] = useState('');
  const [collectionSearch, setCollectionSearch] = useState('');
  const [isPromptFocused, setIsPromptFocused] = useState(false);
  const [generations, setGenerations] = useState<Generation[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [selectedGenerationMenu, setSelectedGenerationMenu] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Media Modal State
  const [showMediaModal, setShowMediaModal] = useState(false);
  const [selectedMediaTab, setSelectedMediaTab] = useState<'uploads' | 'generations' | 'collections' | 'brandAssets'>('uploads');
  const [selectedMediaCount, setSelectedMediaCount] = useState(0);
  const [uploadedImages, setUploadedImages] = useState<Array<{id: string; url: string; name: string}>>([]);
  const [selectedImages, setSelectedImages] = useState<Set<string>>(new Set());
  const [modalType, setModalType] = useState<'start' | 'end' | null>(null);
  const [startFrameImage, setStartFrameImage] = useState<{id: string; url: string; name: string} | null>(null);
  const [endFrameImage, setEndFrameImage] = useState<{id: string; url: string; name: string} | null>(null);
  const [showIterateModal, setShowIterateModal] = useState(false);
  const [selectedGenerationId, setSelectedGenerationId] = useState<string | null>(null);

  // Mock image URLs for video thumbnails
  const mockImages = [
    'https://images.unsplash.com/photo-1689279699483-91fc40564c5f?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3b21hbiUyMHNtaWxpbmclMjB5ZWxsb3clMjBkcmVzcyUyMGZsb3dlcnN8ZW58MXx8fHwxNzcwMDA4NDk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    'https://images.unsplash.com/photo-1760406852142-3316e140db3b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBsaWZlc3R5bGUlMjBwcm9kdWN0JTIwc2NlbmV8ZW58MXx8fHwxNzcwMDA4NDk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
    'https://images.unsplash.com/photo-1567003762442-2078a0da1cee?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhYnN0cmFjdCUyMGNvbG9yZnVsJTIwYXJ0JTIwY3JlYXRpdmV8ZW58MXx8fHwxNzcwMDA4NDk4fDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral',
  ];

  const copyToClipboard = (text: string) => {
    // Fallback method for copying text
    const textArea = document.createElement('textarea');
    textArea.value = text;
    textArea.style.position = 'fixed';
    textArea.style.left = '-999999px';
    textArea.style.top = '-999999px';
    document.body.appendChild(textArea);
    textArea.focus();
    textArea.select();
    try {
      document.execCommand('copy');
      textArea.remove();
    } catch (err) {
      console.error('Failed to copy text: ', err);
      textArea.remove();
    }
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    const newImages: Array<{id: string; url: string; name: string}> = [];
    
    Array.from(files).forEach((file) => {
      if (file.type.startsWith('image/')) {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          newImages.push({
            id: `${Date.now()}-${Math.random()}`,
            url: result,
            name: file.name
          });
          
          // Update state after all files are processed
          if (newImages.length === files.length) {
            setUploadedImages([...uploadedImages, ...newImages]);
          }
        };
        reader.readAsDataURL(file);
      }
    });
  };

  const toggleImageSelection = (imageId: string) => {
    const newSelected = new Set(selectedImages);
    if (newSelected.has(imageId)) {
      newSelected.delete(imageId);
    } else {
      // Only allow one image for start/end frame
      newSelected.clear();
      newSelected.add(imageId);
    }
    setSelectedImages(newSelected);
    setSelectedMediaCount(newSelected.size);
  };

  const handleConfirmImages = () => {
    const selected = uploadedImages.filter(img => selectedImages.has(img.id));
    if (selected.length > 0) {
      if (modalType === 'start') {
        setStartFrameImage(selected[0]);
      } else if (modalType === 'end') {
        setEndFrameImage(selected[0]);
      }
    }
    setShowMediaModal(false);
    setSelectedImages(new Set());
    setSelectedMediaCount(0);
    setModalType(null);
  };

  const removeStartFrame = () => {
    setStartFrameImage(null);
  };

  const removeEndFrame = () => {
    setEndFrameImage(null);
  };

  const handleGenerate = () => {
    if (!prompt.trim()) return;

    setIsGenerating(true);

    // Simulate generation delay
    setTimeout(() => {
      const newGeneration: Generation = {
        id: Date.now().toString(),
        type: 'video',
        prompt: prompt,
        images: [mockImages[Math.floor(Math.random() * mockImages.length)]], // Use an array for images
        model: model === 'Auto' ? 'Veo 3.1' : model,
        dimensions: selectedAspectRatio,
        speed: 'Fast',
        resolution: selectedAspectRatio === '16:9' ? '2K' : selectedAspectRatio === '9:16' ? 'HD' : 'HD',
        timestamp: new Date(),
      };

      setGenerations([newGeneration, ...generations]);
      setIsGenerating(false);
    }, 2000);
  };

  const models = ['Veo 3.1', 'Veo 3.1 Fast'];

  const aspectRatios = [
    { label: '9:16', value: '9:16' },
    { label: '16:9', value: '16:9' },
    { label: '1:1', value: '1:1' },
    { label: 'Custom', value: 'custom' }
  ];

  const durations = [3, 5, 10, 15];

  return (
    <div className="flex flex-col h-screen bg-white">
      {/* Top Navigation Bar - White Theme */}
      <div className="bg-white text-[#1a1a1a] px-4 md:px-8 py-3 flex items-center justify-between border-b border-[#e0e0e0] gap-3">
        {/* Left: Back button and Logo */}
        <div className="flex items-center gap-2 md:gap-4 flex-1">
          <button
            onClick={onBack}
            className="p-1.5 hover:bg-[#f5f5f5] rounded-lg transition-colors flex-shrink-0"
          >
            <ArrowLeft className="w-5 h-5 text-[#6b6b6b]" />
          </button>
          <div className="hidden sm:flex items-center gap-3">
            <div className="w-8 h-8 bg-[#1a1a1a] rounded-lg flex items-center justify-center">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
              </svg>
            </div>
            <span className="font-semibold text-[#1a1a1a]">GenFlow.ai</span>
          </div>
        </div>

        {/* Center: Video Creation Playground with status indicator */}
        <div className="hidden md:flex items-center gap-2 flex-1 justify-center">
          <span className="text-[14px] font-medium text-[#1a1a1a]">Video Creation Playground</span>
          <div className="w-2 h-2 bg-[#0000FF] rounded-full"></div>
        </div>

        {/* Right: Tokens and Upgrade */}
        <div className="flex items-center gap-2 md:gap-3 flex-1 justify-end">
          <div className="flex items-center gap-2 px-2 md:px-3 py-1.5 bg-[#fafafa] border border-[#e0e0e0] rounded-lg">
            <Ticket className="w-4 h-4 text-[#0000FF]" />
            <span className="text-[11px] md:text-[13px] font-semibold text-[#1a1a1a]">150 left</span>
          </div>
          <button className="hidden sm:block px-4 py-1.5 bg-[#0000FF] hover:bg-[#0000CC] text-white rounded-lg font-semibold text-[13px] transition-colors">
            Upgrade
          </button>
        </div>
      </div>

      {/* Main Content Wrapper */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar - Controls */}
        <div className="w-48 md:w-64 bg-[#fafafa] border-r border-[#e0e0e0] p-3 md:p-4 overflow-y-auto flex-shrink-0">
          {/* Model Selector */}
          <div className="mb-6 relative">
            <label className="flex items-center gap-2 text-[13px] font-semibold text-[#1a1a1a] mb-2">
              Model
              <Info className="w-3.5 h-3.5 text-[#9b9b9b]" />
            </label>
            <button
              className="w-full flex items-center justify-between px-3 py-2.5 bg-gradient-to-r from-[#0000FF] to-[#0000CC] text-white rounded-lg text-[14px] font-medium"
              onClick={() => setShowModelDropdown(!showModelDropdown)}
            >
              <span>{model}</span>
              <ChevronDown className="w-4 h-4" />
            </button>
            {showModelDropdown && (
              <div className="absolute mt-1 w-56 bg-white border border-[#e0e0e0] rounded-lg shadow-lg z-10">
                {models.map((m) => (
                  <button
                    key={m}
                    className="w-full px-3 py-2 text-left text-[14px] font-medium text-[#1a1a1a] hover:bg-[#f0f0f0] transition-colors first:rounded-t-lg last:rounded-b-lg flex items-center justify-between"
                    onClick={() => {
                      setModel(m);
                      setShowModelDropdown(false);
                    }}
                  >
                    <span>{m}</span>
                    <GoogleIcon className="w-4 h-4" />
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Video Dimensions */}
          <div className="mb-6">
            <label className="flex items-center gap-2 text-[13px] font-semibold text-[#1a1a1a] mb-3">
              Video Dimensions
              <Info className="w-3.5 h-3.5 text-[#9b9b9b]" />
            </label>
            <div className="grid grid-cols-4 gap-2">
              {aspectRatios.map((ratio) => (
                <button
                  key={ratio.value}
                  onClick={() => setSelectedAspectRatio(ratio.value)}
                  className={`flex flex-col items-center justify-center p-2 rounded-lg border-2 transition-all ${
                    selectedAspectRatio === ratio.value
                      ? 'border-[#0000FF] bg-[#0000FF]/5'
                      : 'border-[#e0e0e0] bg-white hover:border-[#0000FF]/50'
                  }`}
                >
                  <div className={`w-6 h-6 border-2 rounded-sm mb-1 $${
                    selectedAspectRatio === ratio.value ? 'border-[#0000FF]' : 'border-[#9b9b9b]'
                  }`}
                  style={{
                    aspectRatio: ratio.value === '9:16' ? '9/16' : 
                                ratio.value === '16:9' ? '16/9' : 
                                ratio.value === '1:1' ? '1/1' : '1/1'
                  }}
                  />
                  <span className={`text-[11px] font-medium ${
                    selectedAspectRatio === ratio.value ? 'text-[#0000FF]' : 'text-[#6b6b6b]'
                  }`}>
                    {ratio.label}
                  </span>
                </button>
              ))}
            </div>
          </div>

          {/* Video Duration */}
          <div className="mb-6">
            <label className="flex items-center gap-2 text-[13px] font-semibold text-[#1a1a1a] mb-3">
              Duration (seconds)
              <Info className="w-3.5 h-3.5 text-[#9b9b9b]" />
            </label>
            <div className="flex gap-2">
              {durations.map((duration) => (
                <button
                  key={duration}
                  onClick={() => setVideoDuration(duration)}
                  className={`flex-1 py-2 rounded-lg text-[14px] font-semibold transition-all ${
                    videoDuration === duration
                      ? 'bg-[#0000FF] text-white'
                      : 'bg-white border border-[#e0e0e0] text-[#1a1a1a] hover:border-[#0000FF]/50'
                  }`}
                >
                  {duration}s
                </button>
              ))}
              <button className="w-10 h-10 flex items-center justify-center bg-white border border-[#e0e0e0] rounded-lg text-[#6b6b6b] hover:border-[#0000FF]/50 transition-colors">
                <ChevronDown className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Reset to Defaults */}
          <button className="w-full flex items-center justify-center gap-2 px-4 py-2.5 border border-[#e0e0e0] rounded-lg text-[13px] font-medium text-[#6b6b6b] hover:border-[#0000FF] hover:text-[#0000FF] transition-colors">
            <RotateCcw className="w-4 h-4" />
            Reset to Defaults
          </button>
        </div>

        {/* Main Content Area */}
        <div className="flex-1 flex flex-col overflow-hidden">
          {/* Prompt Input Area - Homepage Style */}
          <div className="px-6 py-6">
            {/* Animated Border Wrapper */}
            <div className="relative rounded-2xl p-[2px] bg-gradient-to-r from-transparent via-[#0000FF]/40 to-transparent animate-border-flow">
              <div className={`bg-white backdrop-blur-sm rounded-2xl shadow-lg transition-all relative z-10 ${isPromptFocused ? 'p-6' : 'p-4'}`}>
                {/* Upload Button Row - Only show when focused */}
                {isPromptFocused && selectedTab === 'video' && (
                  <div className="mb-3 flex items-center gap-2">
                    {!startFrameImage && (
                      <button 
                        onMouseDown={(e) => e.preventDefault()} // Prevent blur on input
                        onClick={() => {
                          setModalType('start');
                          setShowMediaModal(true);
                        }}
                      className="flex items-center gap-2.5 px-3.5 py-2.5 bg-[#f8f8f8] hover:bg-[#f0f0f0] border border-[#e0e0e0] rounded-xl transition-colors group relative"
                    >
                      <div className="relative">
                        <ImageIcon className="w-5 h-5 text-[#6b6b6b] group-hover:text-[#1a1a1a]" />
                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#0000FF] rounded-full flex items-center justify-center">
                          <Plus className="w-2 h-2 text-white" />
                        </div>
                        {/* Tooltip on hover */}
                        <div className="absolute bottom-full left-0 mb-2 px-3 py-2 bg-[#1a1a1a] text-white text-[11px] rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-[100]">
                          Select an image to set as the starting frame for your video.
                          <div className="absolute top-full left-4 -mt-1 border-4 border-transparent border-t-[#1a1a1a]"></div>
                        </div>
                      </div>
                      <span className="text-[13px] font-semibold text-[#1a1a1a]">Start Frame</span>
                    </button>
                    )}
                    {/* Arrow Icon */}
                    {(!startFrameImage || !endFrameImage) && (
                      <div className="flex items-center justify-center px-2">
                        <ArrowLeftRight className="w-5 h-5 text-[#9b9b9b]" />
                      </div>
                    )}
                    {!endFrameImage && (
                      <button 
                        onMouseDown={(e) => e.preventDefault()} // Prevent blur on input
                        onClick={() => {
                          setModalType('end');
                          setShowMediaModal(true);
                        }}
                      className="flex items-center gap-2.5 px-3.5 py-2.5 bg-[#f8f8f8] hover:bg-[#f0f0f0] border border-[#e0e0e0] rounded-xl transition-colors group relative"
                    >
                      <div className="relative">
                        <ImageIcon className="w-5 h-5 text-[#6b6b6b] group-hover:text-[#1a1a1a]" />
                        <div className="absolute -top-1 -right-1 w-3 h-3 bg-[#0000FF] rounded-full flex items-center justify-center">
                          <Plus className="w-2 h-2 text-white" />
                        </div>
                        {/* Tooltip on hover */}
                        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-3 py-2 bg-[#1a1a1a] text-white text-[11px] rounded-lg whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-[100]">
                          Select an image to set as the ending frame for your video.
                          <div className="absolute top-full left-1/2 -translate-x-1/2 -mt-1 border-4 border-transparent border-t-[#1a1a1a]"></div>
                        </div>
                      </div>
                      <span className="text-[13px] font-semibold text-[#1a1a1a]">End Frame</span>
                    </button>
                    )}
                  </div>
                )}

                {/* Confirmed Images Display */}
                {(startFrameImage || endFrameImage) && (
                  <div className="mb-3 flex items-center gap-2 flex-wrap">
                    {startFrameImage && (
                      <div className="relative group">
                        <div className="w-16 h-16 rounded-lg overflow-hidden border-2 border-[#0000FF] bg-white shadow-sm">
                          <img 
                            src={startFrameImage.url} 
                            alt={startFrameImage.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        {/* Label */}
                        <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-[#0000FF] text-white text-[9px] font-semibold rounded whitespace-nowrap">
                          Start
                        </div>
                        {/* Remove button */}
                        <button
                          onClick={() => removeStartFrame()}
                          className="absolute -top-2 -right-2 w-5 h-5 bg-[#ff0000] rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
                        >
                          <X className="w-3 h-3 text-white" />
                        </button>
                      </div>
                    )}
                    {/* Arrow between images */}
                    {startFrameImage && endFrameImage && (
                      <div className="flex items-center justify-center px-2">
                        <ArrowLeftRight className="w-5 h-5 text-[#9b9b9b]" />
                      </div>
                    )}
                    {endFrameImage && (
                      <div className="relative group">
                        <div className="w-16 h-16 rounded-lg overflow-hidden border-2 border-[#0000FF] bg-white shadow-sm">
                          <img 
                            src={endFrameImage.url} 
                            alt={endFrameImage.name}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        {/* Label */}
                        <div className="absolute -bottom-1 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-[#0000FF] text-white text-[9px] font-semibold rounded whitespace-nowrap">
                          End
                        </div>
                        {/* Remove button */}
                        <button
                          onClick={() => removeEndFrame()}
                          className="absolute -top-2 -right-2 w-5 h-5 bg-[#ff0000] rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity shadow-md"
                        >
                          <X className="w-3 h-3 text-white" />
                        </button>
                      </div>
                    )}
                  </div>
                )}

                {/* Input Row */}
                <div className={`flex items-center gap-3 ${isPromptFocused ? 'mb-4' : ''} relative`}>
                  <input
                    type="text"
                    value={prompt}
                    onChange={(e) => setPrompt(e.target.value)}
                    onFocus={() => setIsPromptFocused(true)}
                    onBlur={() => {
                      if (prompt.trim() === '') {
                        setIsPromptFocused(false);
                      }
                    }}
                    placeholder={!isPromptFocused && !prompt ? '' : 'Type a prompt...'}
                    className="flex-1 bg-transparent text-[16px] text-[#1a1a1a] placeholder:text-[#9b9b9b] focus:outline-none"
                    style={{
                      caretColor: '#1a1a1a'
                    }}
                  />
                  {!isPromptFocused && !prompt && (
                    <div className="absolute left-0 top-1/2 -translate-y-1/2 pointer-events-none text-[#9b9b9b] text-[16px] flex items-center">
                      <span className="inline-block w-[2px] h-[20px] bg-[#9b9b9b] animate-[blink-cursor_1s_step-end_infinite] mr-1"></span>
                      <span>Type a prompt...</span>
                    </div>
                  )}
                  {!isPromptFocused && (
                    <button 
                      onClick={handleGenerate}
                      disabled={isGenerating || !prompt.trim()}
                      className="px-6 py-2 bg-[#0000FF] text-white rounded-lg font-semibold text-[13px] hover:bg-[#0000CC] transition-colors disabled:opacity-50 disabled:cursor-not-allowed">
                      {isGenerating ? 'Generating...' : 'Generate'}
                    </button>
                  )}
                </div>

                {/* Bottom Row with Tabs and Actions - Only show when focused */}
                {isPromptFocused && (
                  <div className="flex items-center justify-end">
                    {/* Right: Generate Button */}
                    <button 
                      onClick={handleGenerate}
                      disabled={isGenerating || !prompt.trim()}
                      className="px-6 py-2 bg-[#0000FF] text-white rounded-lg font-semibold text-[13px] hover:bg-[#0000CC] transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2">
                      <Sparkles className="w-4 h-4" />
                      {isGenerating ? 'Generating...' : 'Generate'}
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Main Content */}
          <div className="flex-1 overflow-auto px-4 md:px-6 py-4 md:py-6">
            {/* First Generation Message */}
            {generations.length === 0 && !isGenerating && (
              <div className="bg-[#fafafa] border border-[#e0e0e0] rounded-lg p-6 text-center w-full">
                <p className="text-[14px] text-[#6b6b6b]">
                  You are yet to make your first AI video generation. Please type a prompt above to create your first video.
                </p>
              </div>
            )}

            {/* Generations Section */}
            {(generations.length > 0 || isGenerating) && (
              <div className="space-y-6">
                {/* Section Header */}
                <h2 className="text-[20px] font-bold text-[#1a1a1a]">Today</h2>

                {/* Loading State */}
                {isGenerating && (
                  <div className="bg-white border border-[#e0e0e0] rounded-xl overflow-hidden animate-pulse">
                    <div className="flex gap-0 h-[280px]">
                      <div className="w-2/3 bg-[#f5f5f5]"></div>
                      <div className="flex-1 p-6 space-y-4">
                        <div className="h-4 bg-[#f5f5f5] rounded w-3/4"></div>
                        <div className="h-3 bg-[#f5f5f5] rounded w-1/2"></div>
                        <div className="h-3 bg-[#f5f5f5] rounded w-2/3"></div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Generated Videos */}
                {generations.map((generation) => (
                  <div 
                    key={generation.id}
                    className="bg-white border border-[#e0e0e0] rounded-xl p-3 md:p-4 hover:shadow-lg transition-shadow"
                  >
                    <div className="flex flex-col md:flex-row gap-4">
                      {/* Video Thumbnail - Left Side (reduced width) */}
                      <div className="w-full md:w-[45%] relative bg-[#f5f5f5] rounded-lg overflow-hidden flex-shrink-0">
                        <img 
                          src={generation.images[0]} // Use the first image in the array
                          alt={generation.prompt}
                          className="w-full h-full object-cover"
                          style={{ height: '250px' }}
                        />
                        {/* Play Icon Overlay */}
                        <div className="absolute inset-0 flex items-center justify-center">
                          <div className="w-16 h-16 bg-white/90 rounded-full flex items-center justify-center hover:bg-white transition-colors cursor-pointer">
                            <svg className="w-8 h-8 text-[#0000FF] ml-1" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M8 5v14l11-7z"/>
                            </svg>
                          </div>
                        </div>
                      </div>

                      {/* Content - Right Side */}
                      <div className="flex-1 flex flex-col justify-between">
                        {/* Top Section */}
                        <div className="space-y-4">
                          {/* Prompt with Copy Icon */}
                          <div className="flex items-start gap-2 group">
                            <p className="text-[14px] text-[#1a1a1a] leading-relaxed flex-1">
                              {generation.prompt}
                            </p>
                            <div className="relative">
                              <button 
                                onClick={() => {
                                  copyToClipboard(generation.prompt);
                                  setCopiedId(generation.id);
                                  setTimeout(() => setCopiedId(null), 2000);
                                }}
                                className="p-1.5 hover:bg-[#f5f5f5] rounded transition-colors opacity-0 group-hover:opacity-100"
                                title="Copy prompt"
                              >
                                <Copy className="w-4 h-4 text-[#6b6b6b]" />
                              </button>
                              {copiedId === generation.id && (
                                <div className="absolute right-0 top-full mt-1 px-2 py-1 bg-[#1a1a1a] text-white text-[11px] rounded whitespace-nowrap">
                                  Copied!
                                </div>
                              )}
                            </div>
                          </div>

                          {/* Metadata - Grey Card Badges */}
                          <div className="flex items-center gap-2 text-[12px]">
                            {/* Model Badge */}
                            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#f5f5f5] rounded-lg border border-[#e0e0e0]">
                              <div className="w-1.5 h-1.5 bg-[#0000FF] rounded-full"></div>
                              <span className="font-medium text-[#1a1a1a]">{generation.model}</span>
                            </div>
                            {/* Dimensions Badge */}
                            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#f5f5f5] rounded-lg border border-[#e0e0e0]">
                              <Crop className="w-3.5 h-3.5 text-[#6b6b6b]" />
                              <span className="font-medium text-[#1a1a1a]">{generation.dimensions}</span>
                            </div>
                            {/* Resolution Badge */}
                            <div className="flex items-center gap-1.5 px-3 py-1.5 bg-[#f5f5f5] rounded-lg border border-[#e0e0e0]">
                              <Maximize2 className="w-3.5 h-3.5 text-[#6b6b6b]" />
                              <span className="font-medium text-[#1a1a1a]">{generation.resolution}</span>
                            </div>
                          </div>

                          {/* Action Buttons */}
                          <div className="flex items-center gap-2 pt-2">
                            <button className="flex items-center gap-2 px-4 py-2 bg-white border border-[#e0e0e0] hover:bg-[#f5f5f5] text-[#1a1a1a] rounded-lg text-[13px] font-semibold transition-colors"
                              onClick={() => {
                                setShowIterateModal(true);
                                setSelectedGenerationId(generation.id);
                              }}
                            >
                              <RotateCcw className="w-4 h-4" />
                              Iterate
                            </button>
                            <div className="relative group">
                              <button className="p-2 bg-[#f5f5f5] hover:bg-[#e0e0e0] rounded-lg transition-colors shadow-sm">
                                <Download className="w-4 h-4 text-[#1a1a1a]" />
                              </button>
                              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-[#1a1a1a] text-white text-[11px] rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                Download all
                              </div>
                            </div>
                            <div className="relative group">
                              <button className="p-2 bg-[#f5f5f5] hover:bg-[#e0e0e0] rounded-lg transition-colors shadow-sm">
                                <Trash2 className="w-4 h-4 text-[#1a1a1a]" />
                              </button>
                              <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 px-2 py-1 bg-[#1a1a1a] text-white text-[11px] rounded whitespace-nowrap opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none">
                                Delete all
                              </div>
                            </div>
                            <div className="relative">
                              <button 
                                onClick={() => setSelectedGenerationMenu(selectedGenerationMenu === generation.id ? null : generation.id)}
                                className="p-2 bg-[#f5f5f5] hover:bg-[#e0e0e0] rounded-lg transition-colors shadow-sm"
                              >
                                <MoreVertical className="w-4 h-4 text-[#1a1a1a]" />
                              </button>
                              
                              {/* Dropdown Menu */}
                              {selectedGenerationMenu === generation.id && (
                                <div className="absolute right-0 top-full mt-1 w-48 bg-white border border-[#e0e0e0] rounded-lg shadow-lg z-50 overflow-hidden">
                                  <button className="w-full flex items-center gap-3 px-4 py-3 hover:bg-[#f5f5f5] transition-colors text-left">
                                    <ExternalLink className="w-4 h-4 text-[#6b6b6b]" />
                                    <span className="text-[14px] text-[#1a1a1a]">Share</span>
                                  </button>
                                </div>
                              )}
                            </div>
                          </div>
                        </div>

                        {/* Bottom Section - Feedback */}
                        <div className="pt-4 border-t border-[#e0e0e0] mt-4">
                          <div className="flex items-center justify-between">
                            <span className="text-[13px] text-[#6b6b6b]">How was this output?</span>
                            <div className="flex items-center gap-2">
                              <button className="p-1.5 hover:bg-[#f5f5f5] rounded transition-colors">
                                <svg className="w-4 h-4 text-[#6b6b6b]" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M14 9V5a3 3 0 0 0-3-3l-4 9v11h11.28a2 2 0 0 0 2-1.7l1.38-9a2 2 0 0 0-2-2.3zM7 22H4a2 2 0 0 1-2-2v-7a2 2 0 0 1 2-2h3" />
                                </svg>
                              </button>
                              <button className="p-1.5 hover:bg-[#f5f5f5] rounded transition-colors">
                                <svg className="w-4 h-4 text-[#6b6b6b]" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                                  <path strokeLinecap="round" strokeLinejoin="round" d="M10 15v4a3 3 0 0 0 3 3l4-9V2H5.72a2 2 0 0 0-2 1.7l-1.38 9a2 2 0 0 0 2 2.3zm7-13h2.67A2.31 2.31 0 0 1 22 4v7a2.31 2.31 0 0 1-2.33 2H17" />
                                </svg>
                              </button>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Select Asset Modal */}
      {showMediaModal && (
        <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-[100]" onClick={() => setShowMediaModal(false)}>
          <div className="bg-white rounded-2xl w-[90%] max-w-4xl h-[80vh] flex flex-col" onClick={(e) => e.stopPropagation()}>
            {/* Header */}
            <div className="flex items-center justify-between px-6 py-4 border-b border-[#e0e0e0]">
              <h2 className="text-[20px] font-bold text-[#1a1a1a]">Select Asset</h2>
              <button 
                onClick={() => setShowMediaModal(false)}
                className="p-2 hover:bg-[#f5f5f5] rounded-full transition-colors"
              >
                <X className="w-5 h-5 text-[#6b6b6b]"/>
              </button>
            </div>

            {/* Tabs */}
            <div className="flex items-center gap-1 px-6 py-3 border-b border-[#e0e0e0]">
              <button 
                onClick={() => setSelectedMediaTab('uploads')}
                className={`px-4 py-2 rounded-lg text-[13px] font-medium transition-colors ${
                  selectedMediaTab === 'uploads' 
                    ? 'bg-[#0000FF] text-white' 
                    : 'text-[#6b6b6b] hover:bg-[#f5f5f5]'
                }`}
              >
                Your Uploads
              </button>
              <button 
                onClick={() => setSelectedMediaTab('generations')}
                className={`px-4 py-2 rounded-lg text-[13px] font-medium transition-colors ${
                  selectedMediaTab === 'generations' 
                    ? 'bg-[#0000FF] text-white' 
                    : 'text-[#6b6b6b] hover:bg-[#f5f5f5]'
                }`}
              >
                Generations
              </button>
              <button 
                onClick={() => setSelectedMediaTab('brandAssets')}
                className={`px-4 py-2 rounded-lg text-[13px] font-medium transition-colors ${
                  selectedMediaTab === 'brandAssets' 
                    ? 'bg-[#0000FF] text-white' 
                    : 'text-[#6b6b6b] hover:bg-[#f5f5f5]'
                }`}
              >
                Brand Assets
              </button>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-auto p-6">
              {selectedMediaTab === 'uploads' && (
                <>
                  {uploadedImages.length === 0 ? (
                    <div className="flex flex-col items-center justify-center h-full">
                      <label htmlFor="file-upload" className="w-48 h-48 border-2 border-dashed border-[#e0e0e0] rounded-2xl flex flex-col items-center justify-center gap-4 hover:border-[#0000FF] hover:bg-[#0000FF]/5 transition-all cursor-pointer">
                        <div className="w-16 h-16 bg-[#f5f5f5] rounded-full flex items-center justify-center">
                          <Upload className="w-8 h-8 text-[#6b6b6b]"/>
                        </div>
                        <div className="text-center">
                          <p className="text-[14px] font-medium text-[#1a1a1a] mb-1">Upload an image</p>
                          <p className="text-[12px] text-[#6b6b6b]">PNG, JPG or WEBP up to 5MB</p>
                        </div>
                      </label>
                      <input 
                        type="file" 
                        multiple 
                        accept="image/*" 
                        className="hidden" 
                        id="file-upload" 
                        onChange={handleFileUpload}
                      />
                    </div>
                  ) : (
                    <div className="grid grid-cols-3 gap-4">
                      {/* Upload Square - First Item */}
                      <label htmlFor="file-upload-add" className="border-2 border-dashed border-[#e0e0e0] rounded-2xl flex flex-col items-center justify-center gap-4 hover:border-[#0000FF] hover:bg-[#0000FF]/5 transition-all cursor-pointer aspect-square">
                        <div className="w-16 h-16 bg-[#f5f5f5] rounded-full flex items-center justify-center">
                          <Upload className="w-8 h-8 text-[#6b6b6b]"/>
                        </div>
                        <div className="text-center px-4">
                          <p className="text-[14px] font-medium text-[#1a1a1a] mb-1">Upload an image</p>
                          <p className="text-[12px] text-[#6b6b6b]">PNG, JPG or WEBP up to 5MB</p>
                        </div>
                      </label>
                      <input 
                        type="file" 
                        multiple 
                        accept="image/*" 
                        className="hidden" 
                        id="file-upload-add" 
                        onChange={handleFileUpload}
                      />
                      
                      {/* Uploaded Images */}
                      {uploadedImages.map((image) => (
                        <div 
                          key={image.id}
                          className={`relative bg-[#f5f5f5] rounded-lg overflow-hidden aspect-square cursor-pointer transition-all ${
                            selectedImages.has(image.id) ? 'ring-4 ring-[#0000FF]' : ''
                          }`}
                          onClick={() => toggleImageSelection(image.id)}
                        >
                          <img 
                            src={image.url} 
                            alt={image.name}
                            className="w-full h-full object-cover"
                          />
                          {/* Selection Indicator */}
                          {selectedImages.has(image.id) && (
                            <div className="absolute top-3 right-3 w-6 h-6 bg-[#0000FF] rounded-full flex items-center justify-center">
                              <svg className="w-4 h-4 text-white" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                                <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                              </svg>
                            </div>
                          )}
                        </div>
                      ))}
                    </div>
                  )}
                </>
              )}
              {selectedMediaTab !== 'uploads' && (
                <div className="flex items-center justify-center h-full">
                  <p className="text-[14px] text-[#6b6b6b]">No media available</p>
                </div>
              )}
            </div>

            {/* Footer */}
            <div className="flex items-center justify-between px-6 py-4 border-t border-[#e0e0e0]">
              <div className="flex items-center gap-2 text-[13px] text-[#6b6b6b]">
                <Info className="w-4 h-4 text-[#0000FF]"/>
                <span>{selectedMediaCount === 1 ? '1 selected' : 'Select 1 image'}</span>
              </div>
              <div className="flex items-center gap-3">
                <button 
                  onClick={() => setShowMediaModal(false)}
                  className="px-6 py-2 border border-[#e0e0e0] rounded-lg text-[13px] font-medium text-[#1a1a1a] hover:bg-[#f5f5f5] transition-colors"
                >
                  Cancel
                </button>
                <button 
                  className="px-6 py-2 bg-[#0000FF] text-white rounded-lg text-[13px] font-medium hover:bg-[#0000CC] transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                  disabled={selectedMediaCount === 0}
                  onClick={handleConfirmImages}
                >
                  Confirm
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
      {/* Iterate Modal */}
      {showIterateModal && (
        <IterateModal
          onClose={() => setShowIterateModal(false)}
          generationId={selectedGenerationId}
        />
      )}
    </div>
  );
}
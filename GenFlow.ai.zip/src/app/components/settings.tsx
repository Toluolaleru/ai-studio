import { useState } from 'react';
import { 
  User, 
  Users,
  CreditCard, 
  ChevronDown,
  Trash2,
  Mail,
  ArrowLeft,
  Ticket,
  BarChart3
} from 'lucide-react';
import { TeamMembers } from './team-members';
import { UsageBilling } from './usage-billing';

interface Team {
  id: string;
  name: string;
  description: string;
  type: 'personal' | 'team';
}

interface TeamMember {
  id: string;
  email: string;
  name: string;
  role: 'owner' | 'admin' | 'member' | 'viewer';
  status: 'active' | 'pending';
  joinedAt: string;
}

interface SettingsProps {
  userEmail: string;
  onBack?: () => void;
  currentTeam?: Team;
  teamMembers?: TeamMember[];
  onInviteMember?: () => void;
  onRemoveMember?: (memberId: string) => void;
  onUpdateMemberRole?: (memberId: string, newRole: 'admin' | 'member' | 'viewer') => void;
  initialTab?: 'profile' | 'members' | 'billing';
}

export function Settings({ 
  userEmail, 
  onBack,
  currentTeam,
  teamMembers = [],
  onInviteMember = () => {},
  onRemoveMember = () => {},
  onUpdateMemberRole = () => {},
  initialTab = 'profile'
}: SettingsProps) {
  const [email, setEmail] = useState(userEmail);
  const [activeSettingsTab, setActiveSettingsTab] = useState(initialTab);

  return (
    <div className="flex flex-col h-screen bg-white flex-1">
      {/* Top Header */}
      <div className="flex items-center justify-between px-4 md:px-6 py-4 border-b border-[#e0e0e0]">
        {/* Left: Back Button and Title */}
        <div className="flex items-center gap-2 md:gap-4">
          <button 
            onClick={onBack}
            className="p-2 hover:bg-[#f5f5f5] rounded-lg transition-colors"
          >
            <ArrowLeft className="w-5 h-5 text-[#1a1a1a]" />
          </button>
          <h1 className="text-[16px] md:text-[18px] font-bold text-[#1a1a1a]">Settings</h1>
        </div>

        {/* Right: Tokens and Upgrade */}
        <div className="flex items-center gap-2 md:gap-3">
          <div className="flex items-center gap-2 px-2 md:px-3 py-2 bg-[#fafafa] rounded-lg">
            <Ticket className="w-4 h-4 md:w-5 md:h-5 text-[#5865f2]" />
            <span className="text-[12px] md:text-[14px] font-semibold text-[#1a1a1a]">150 left</span>
          </div>
          <button className="hidden sm:block px-4 py-2 bg-[#5865f2] hover:bg-[#4752c4] text-white rounded-lg font-semibold text-[14px] transition-colors">
            Upgrade
          </button>
        </div>
      </div>

      {/* Main Layout */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left Sidebar */}
        <div className="w-48 md:w-64 bg-[#fafafa] border-r border-[#e0e0e0] p-3 md:p-4 overflow-y-auto">
          {/* Personal Settings */}
          <div className="mb-6">
            <h3 className="text-[10px] md:text-[11px] font-semibold text-[#9b9b9b] uppercase tracking-wider mb-3 px-3">
              Personal Settings
            </h3>
            <button 
              onClick={() => setActiveSettingsTab('profile')}
              className={`w-full flex items-center gap-2 md:gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                activeSettingsTab === 'profile' ? 'bg-transparent text-[#0000FF]' : 'hover:bg-[#f5f5f5] text-[#1a1a1a]'
              }`}
            >
              <User className="w-4 h-4 flex-shrink-0" />
              <span className="text-[13px] md:text-[14px] font-medium">Your Profile</span>
            </button>
          </div>

          {/* Workspace Settings */}
          <div>
            <h3 className="text-[10px] md:text-[11px] font-semibold text-[#9b9b9b] uppercase tracking-wider mb-3 px-3">
              Workspace Settings
            </h3>
            
            {/* Workspace Selector */}
            <button className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-[#f5f5f5] transition-colors mb-2">
              <div className="flex items-center gap-2">
                <div className="w-6 h-6 bg-[#0000FF] rounded-full flex items-center justify-center text-white font-semibold text-[11px]">
                  {currentTeam ? currentTeam.name.charAt(0).toUpperCase() : userEmail.charAt(0).toUpperCase()}
                </div>
                <span className="text-[14px] font-medium text-[#1a1a1a]">
                  {currentTeam ? currentTeam.name : userEmail.split('@')[0]}
                </span>
              </div>
              <ChevronDown className="w-4 h-4 text-[#6b6b6b]" />
            </button>

            {/* Members - Only show for teams */}
            {currentTeam && currentTeam.type === 'team' && (
              <button 
                onClick={() => setActiveSettingsTab('members')}
                className={`w-full flex items-center gap-2 md:gap-3 px-3 py-2.5 rounded-lg transition-colors mb-2 ${
                  activeSettingsTab === 'members' ? 'bg-transparent text-[#0000FF]' : 'hover:bg-[#f5f5f5] text-[#1a1a1a]'
                }`}
              >
                <Users className="w-4 h-4 flex-shrink-0" />
                <span className="text-[13px] md:text-[14px] font-medium">Members</span>
              </button>
            )}

            {/* Usage & Billing */}
            <button 
              onClick={() => setActiveSettingsTab('billing')}
              className={`w-full flex items-center gap-2 md:gap-3 px-3 py-2.5 rounded-lg transition-colors mb-2 ${
                activeSettingsTab === 'billing' ? 'bg-transparent text-[#0000FF]' : 'hover:bg-[#f5f5f5] text-[#1a1a1a]'
              }`}
            >
              <BarChart3 className="w-4 h-4 flex-shrink-0" />
              <span className="text-[13px] md:text-[14px] font-medium">Usage & Billing</span>
            </button>

            {/* Subscription */}
            <button className="w-full flex items-center justify-between px-3 py-2.5 rounded-lg hover:bg-[#f5f5f5] transition-colors">
              <div className="flex items-center gap-3">
                <CreditCard className="w-4 h-4 text-[#6b6b6b]" />
                <span className="text-[14px] font-medium text-[#1a1a1a]">Subscription</span>
              </div>
              <div className="w-2 h-2 bg-[#5865f2] rounded-full"></div>
            </button>
          </div>
        </div>

        {/* Main Content */}
        <div className="flex-1 overflow-auto bg-white">
          {activeSettingsTab === 'profile' ? (
            <div className="w-full px-4 sm:px-8 md:px-12 py-6 md:py-8">
              {/* Your Profile Section */}
              <div className="mb-12">
                <h2 className="text-[22px] md:text-[28px] font-bold text-[#1a1a1a] mb-6 md:mb-8">Your Profile</h2>
                
                {/* Email Field */}
                <div className="mb-8">
                  <label className="block text-[13px] font-medium text-[#6b6b6b] mb-2">
                    Your Email
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-[#6b6b6b]" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 bg-[#fafafa] border border-[#e0e0e0] rounded-lg text-[14px] text-[#1a1a1a] focus:outline-none focus:ring-2 focus:ring-[#0000FF] focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              {/* Delete Account Section */}
              <div className="border-t border-[#e0e0e0] pt-8">
                <h3 className="text-[18px] font-bold text-[#1a1a1a] mb-2">Delete Account</h3>
                <p className="text-[14px] text-[#6b6b6b] mb-6 leading-relaxed">
                  Deleting your account will remove all of your information from our database. This cannot be undone.
                </p>
                <button className="flex items-center gap-2 px-5 py-2.5 bg-[#dc2626] hover:bg-[#b91c1c] text-white rounded-lg font-semibold text-[13px] transition-colors">
                  <Trash2 className="w-4 h-4" />
                  Delete Account
                </button>
              </div>
            </div>
          ) : activeSettingsTab === 'members' && currentTeam ? (
            <TeamMembers
              teamName={currentTeam.name}
              teamId={currentTeam.id}
              currentUserEmail={userEmail}
              members={teamMembers}
              onInviteMember={onInviteMember}
              onRemoveMember={onRemoveMember}
              onUpdateRole={onUpdateMemberRole}
            />
          ) : activeSettingsTab === 'billing' ? (
            <UsageBilling />
          ) : null}
        </div>
      </div>
    </div>
  );
}